
<header class="desktop_header_section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="desktop-header">

                    <div class="site_logo">
                        <img src="../images/main_logo.png" alt="">
                    </div>

                    <div class="navbar_list">
                        <ul>
                            <li><a href="javascript:;" class="navbar_links">HOME</a></li>
                            <li><a href="javascript" class="navbar_links">ABOUT US</a></li>
                            <li><a href="javascript:;" class="navbar_links">CONTACT US</a></li>
                        </ul>
                    </div>

                    <div class="navbar_right_icons">
                        <a href="javascript:;">
                            <span class="right_icon mr-3"><i class="fa-solid fa-magnifying-glass"></i></span>
                        </a>

                        <a href="javascript:;" class="second_child">
                            <span class="right_icon"><i class="fa-regular fa-user"></i></span>
                        </a>

                        <div class="dropdown show">
                            <a class="right_icon" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-regular fa-user"></i>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="#">Home</a>
                                <a class="dropdown-item" href="#">About Us</a>
                                <a class="dropdown-item" href="#">Contact Us</a>
                            </div>
                        </div>

                        
                    </div>

                </div>
            </div>
        </div>
    </div>
</header>