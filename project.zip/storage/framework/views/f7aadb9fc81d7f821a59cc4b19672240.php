
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Games boxes buy list</h3>
            </div>
        </div>


        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!--<div >-->
        <!--    <h4 class="text-center"><?php echo e(auth()->user()->alias); ?> Your Total Payment is: $<?php echo e(count($boxes) > 0 ? $total : 0); ?></h4>-->
        <!--    -->
        <!--</div>-->
        <div class="row">

            
            <!--<div class="col-md-6 d-flex justify-content-start"><button class="btn btn-danger">Pay -->
            <!--</button></div>-->

            <div class="text-end">
                Hello : <b><?php echo e(auth()->user()->alias); ?></b>
            </div>

            <div class="col-md-12 pt-5 table-responsive">
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No</th>
                            <th class="table-site-headings">Game Board Title</th>
                            <th class="table-site-headings">Board Price</th>
                            <th class="table-site-headings">Board Part</th>
                            <th class="table-site-headings">Number Of Box</th>
                            <th class="table-site-headings">Amount</th>
                            <th class="table-site-headings">Payment Status</th>
                            <th class="table-site-headings">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count_sn = 1;
                        ?>
                        <?php if(count($boxes) > 0): ?>
                            <?php $__currentLoopData = $boxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <tr>

                                    <td><?php echo e($count_sn++); ?></td>
                                    <td><?php echo e($box->boardName->board_name); ?></td>
                                    <td>$<?php echo e($box->price); ?></td>
                                    <td><?php echo e($box->part); ?></td>
                                    <?php
                                        $totalSquareArray = json_decode($box->total_square, true);
                                    ?>
                                    <td><?php echo e($totalSquareCount = count($totalSquareArray)); ?></td>
                                    <td>$<?php echo e($totalPrice = $box->price * $totalSquareCount); ?></td>

                                    <?php if($box->status == 1): ?>
                                        <td class="border-0 font-weight-bold">
                                            <span class="text-success">Paid</span>
                                        </td>
                                    <?php else: ?>
                                        <td class="border-0 font-weight-bold">
                                            <span class="text-danger">Unpaid</span>
                                        </td>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->payment_type == 1): ?>
                                        
                                        <td>
                                            <a href="#" class="btn btn-sm btn-primary">Cashapp</a>
                                        </td>
                                    <?php elseif(auth()->user()->payment_type == 2): ?>
                                        
                                        <td>
                                            <a href="#" class="btn btn-sm btn-primary">Venmo</a>
                                        </td>
                                    <?php elseif(auth()->user()->payment_type == 3): ?>
                                        
                                        <?php if($dateFormat >= $box->boardName->payment_start_date && $dateFormat <= $box->boardName->payment_deadline): ?>
                                            <?php if($box->status == 0): ?>
                                                <td>
                                                    <a href="<?php echo e(route('make.payment', [$totalPrice, $box->boardName->id, $box->price, $box->part])); ?>"
                                                        class="btn btn-sm btn-primary">Pay with PayPal👉</a>
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    
                                                    <span class="badge badge-pill badge-success">Paid</span>
                                                </td>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($box->status == 0): ?>
                                                <td>
                                                    <a href="#" class="btn btn-sm btn-primary">Please Wait For Opening
                                                        Payment</a>
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    
                                                    <span class="badge badge-pill badge-success">Paid</span>
                                                </td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

            
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.user-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sq\resources\views/user/boxbuy/current_game_box_buy.blade.php ENDPATH**/ ?>