<?php if(\Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(\Session::get('success')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\office_work\square_junkie\resources\views/components/success-message.blade.php ENDPATH**/ ?>