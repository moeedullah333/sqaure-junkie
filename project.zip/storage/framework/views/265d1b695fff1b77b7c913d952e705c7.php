<?php $__env->startSection('content'); ?>

    

    



    



    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">

        <div class="row justify-content-between">

            <div class="col-md-12 mb-3">

                <h3 class="achivpFont">Boards</h3>

            </div>

        </div>



        <style>

            .form-group label {

                font-weight: 800;

            }

        </style>





        <form action="<?php echo e(route('admin.board_store')); ?>" method="post">

            <?php echo csrf_field(); ?>

            <div class="container">

                <div class="row">

                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="board-name">Board Name</label>

                            <input type="text" class="form-control" required id="board-name"

                                placeholder="Enter Board Name" name="board_name">

                            <?php $__errorArgs = ['board_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label>Status</label>

                            <select name="status" class="form-control">

                                <option value="1">Active</option>

                                <option value="0">Inactive</option>

                            </select>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="team-name-x">Team Name X</label>

                            <input type="text" class="form-control" required id="team-name-x"

                                placeholder="Enter team Name X" name="team_name_x">

                            <?php $__errorArgs = ['team_name_x'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="team-name-y">Team Name Y</label>

                            <input type="text" class="form-control" required id="team-name-y"

                                placeholder="Enter team Name Y" name="team_name_y">

                            <?php $__errorArgs = ['team_name_y'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="generate_number-date">Set Other Board Price</label>

                            <input type="number" class="form-control" value="0" placeholder="Enter Other Price" min="0" step="any"

                                name="other_value">

                            <?php $__errorArgs = ['other_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="voting-start-date">Voting Start (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="voting-start-date"

                                name="voting_start_date">

                            <?php $__errorArgs = ['voting_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="voting-date">Voting Deadline (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="voting-date"

                                name="voting_deadline">

                            <?php $__errorArgs = ['voting_deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="square-start-date">Square Selection Start (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="square-start-date"

                                name="square_start_date">

                            <?php $__errorArgs = ['square_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="square-deadline-date">Square Selection End (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="square-deadline-date"

                                name="square_deadline_date">

                            <?php $__errorArgs = ['square_deadline_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="payment_start-date">Payment Start (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="payment_start-date"

                                name="payment_start_date">

                            <?php $__errorArgs = ['payment_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="payment_deadline-date">Payment End (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="payment_deadline-date"

                                name="payment_deadline_date">

                            <?php $__errorArgs = ['payment_deadline_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                    



                    <div class="col-md-6">

                        <div class="form-group">

                            <label for="generate_number-date">Generate Number (DATE)</label>

                            <input type="datetime-local" class="form-control" required id="generate_number-date"

                                name="generate_number_date">

                            <?php $__errorArgs = ['generate_number_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <span class="text-danger"><?php echo e($message); ?></span>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                    </div>



                </div>

            </div>

            <button type="submit" class="btn btn-primary">Submit</button>

        </form>



    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

    <script>

        $(document).ready(function() {



            $('#voting-start-date').on('change', function() {

                var datetimeValue = $(this).val();



                let test = $('#voting-date').removeAttr('disabled').attr({

                    "min": datetimeValue,

                });



            });



            $('#voting-date').on('change', function() {

                var datetimeValue = $(this).val();



                let test = $('#square-start-date').removeAttr('disabled').attr({

                    "min": datetimeValue,

                });



            });



            $('#square-start-date').on('change', function() {

                var datetimeValue = $(this).val();



                let test = $('#square-deadline-date').removeAttr('disabled').attr({

                    "min": datetimeValue,

                });



            });



            $('#square-deadline-date').on('change', function() {

                var datetimeValue = $(this).val();



                let test = $('#payment_start-date').removeAttr('disabled').attr({

                    "min": datetimeValue,

                });



            });



            $('#payment_start-date').on('change', function() {

                var datetimeValue = $(this).val();



                let test = $('#payment_deadline-date').removeAttr('disabled').attr({

                    "min": datetimeValue,

                });



            });



            $('#payment_deadline-date').on('change', function() {

                var datetimeValue = $(this).val();



                let test = $('#generate_number-date').removeAttr('disabled').attr({

                    "min": datetimeValue,

                });



            });



            $('input[type=datetime-local]').not(':first').each(function() {



                $(this).attr('disabled', true);

            });

        });

    </script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custom3mystaging/public_html/square_junkie/resources/views/admin/board/creat.blade.php ENDPATH**/ ?>