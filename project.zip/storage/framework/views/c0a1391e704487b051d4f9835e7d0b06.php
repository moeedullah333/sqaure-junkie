

<?php $__env->startSection('content'); ?>
    <section class="immersive_gameplay_section">
        <div class="container">
            <div class="row">
                <img src="<?php echo e(asset('assets/new_website/images/empty-logo.png')); ?>" class="empty-logo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/right-blogo.png')); ?>" class="right-blogo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/c-logo.png')); ?>" class="c-logo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/s-logo.png')); ?>" class="sm-slogo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/b-logo.png')); ?>" class="b-logo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/s-logo.png')); ?>" class="second_slogo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/a-S-logo.png')); ?>" class="first_slogo" alt="">

                <div class="col-md-8 mx-auto">
                    <h2 class="main_heading text-center">BOARD VOTING LIST</h2>
                </div>


                <?php if (isset($component)) { $__componentOriginale879b590e7465e1b7997c63670a370ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale879b590e7465e1b7997c63670a370ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale879b590e7465e1b7997c63670a370ad)): ?>
<?php $attributes = $__attributesOriginale879b590e7465e1b7997c63670a370ad; ?>
<?php unset($__attributesOriginale879b590e7465e1b7997c63670a370ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale879b590e7465e1b7997c63670a370ad)): ?>
<?php $component = $__componentOriginale879b590e7465e1b7997c63670a370ad; ?>
<?php unset($__componentOriginale879b590e7465e1b7997c63670a370ad); ?>
<?php endif; ?>

            </div>
        </div>

    </section>


    <section class="board_voting_list_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="main_heading text-center mb-4">board voting list</h2>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="first_head_row pl-4">
                                        <h6># BOARD NAME</h6>
                                    </th>
                                    <th>
                                        <h6>VOTING DEADLINE</h6>
                                    </th>
                                    <th>
                                        <h6>GAME DATE</h6>
                                    </th>
                                    <th class="status_row">
                                        <h6>STATUS</h6>
                                    </th>
                                    <th class="action_btn_row">
                                        <h6>ACTION</h6>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $count = 1;
                                ?>

                                <?php if($boards->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="first_row pl-4">
                                                    <span><?php echo e($count++); ?></span><span
                                                        class="pl-3"><?php echo e($board->board_name); ?></span>
                                                </div>
                                            </td>

                                            <td>
                                                <div>
                                                    <span><?php echo e($board->voting_deadline); ?></span>
                                                </div>
                                            </td>

                                            <td>
                                                <div>
                                                    <span><?php echo e($board->game_date); ?></span>
                                                </div>
                                            </td>

                                            <?php if($board->status == 1): ?>
                                                <td>
                                                    <div>
                                                        <span class="text-success">Active</span>
                                                    </div>
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    <div>
                                                        <span class="text-danger">Inactive</span>
                                                    </div>
                                                </td>
                                            <?php endif; ?>

                                            <?php if($board->status == 1): ?>
                                                <td>
                                                    <div class="last_row">
                                                        <!-- <button>Action</button> -->
                                                        <a href="<?php echo e(route('voting', $board->id)); ?>">View</a>
                                                    </div>
                                                </td>
                                            <?php else: ?>
                                                <td>
                                                    <div class="last_row">
                                                        <!-- <button>Action</button> -->
                                                        <a href="javascript:void(0)">Board Inactive</a>
                                                    </div>
                                                </td>
                                            <?php endif; ?>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No data available in table</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        var swiper = new Swiper(".whychooseusSwiper", {
            slidesPerView: 3,
            spaceBetween: 30,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
        });



        var swiper = new Swiper(".mySwiper", {
            effect: "cube",
            grabCursor: true,
            cubeEffect: {
                shadow: true,
                slideShadows: true,
                shadowOffset: 20,
                shadowScale: 0.94,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('new_website.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/new_website/pages/board_list.blade.php ENDPATH**/ ?>