<div class="col-md-10 mx-auto mt-5">

    <div class="main_swiper_slider">

        <div class="swiper mySwiper">
            <div class="swiper-wrapper">

                <div class="swiper-slide">
                    <img src="<?php echo e(asset('assets/new_website/images/slider-img.png')); ?>"
                        class="img-fluid" />
                </div>

                <div class="swiper-slide">
                    <img src="<?php echo e(asset('assets/new_website/images/slider-img.png')); ?>"
                        class="img-fluid" />
                </div>

                <div class="swiper-slide">
                    <img src="<?php echo e(asset('assets/new_website/images/slider-img.png')); ?>"
                        class="img-fluid" />
                </div>

                <div class="swiper-slide">
                    <img src="<?php echo e(asset('assets/new_website/images/slider-img.png')); ?>"
                        class="img-fluid" />
                </div>

            </div>

            <div class="swiper-button-next"><i class="fa-solid fa-arrow-right swiper_arrows"></i>
            </div>
            <div class="swiper-button-prev"><i class="fa-solid fa-arrow-left swiper_arrows"></i></div>
            <div class="swiper-pagination"></div>
        </div>

    </div>

</div><?php /**PATH C:\xampp\htdocs\office_work\square_junkie\resources\views/components/main-banner.blade.php ENDPATH**/ ?>