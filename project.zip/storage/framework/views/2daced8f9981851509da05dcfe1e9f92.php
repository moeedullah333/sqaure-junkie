<div class="border-end bg-white h-100" id="sidebar-wrapper">
    <div class="sidebar-heading">
        <a href="<?php echo e(route('admin_dashboard')); ?>">
            <h2>Square <span>Jungle</span></h2>
        </a>
    </div>
    <div class="list-group-flush">
        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('admin_dashboard')); ?>">
            Dashboard</a>
        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('admin_users')); ?>">
            User Management</a>
        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('user_contact_list')); ?>">
            Contact Management</a>
        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('admin.board_list')); ?>">
            Game Management </a>

        

        

        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('board.delete.list')); ?>">
            Deleted Boards </a>

        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('board.part.delete.list')); ?>">
            Deleted Board Parts </a>

        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('admin.percentage.show')); ?>">
            Percentage </a>

        <a class="list-group-item list-group-item-action achivpFont"
            href="<?php echo e(route('admin.number.generation.list')); ?>">
            Number Generation </a>

        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('admin.users.payment')); ?>">
            Payment </a>

        <a class="list-group-item list-group-item-action achivpFont" href="<?php echo e(route('admin.archive-baord')); ?>">
            Archive </a>

        
        <!-- <a class="list-group-item list-group-item-action achivpFont" href="../subscription/subscription.php">
            Subscription Management</a> -->
        
    </div>
</div>
<?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>