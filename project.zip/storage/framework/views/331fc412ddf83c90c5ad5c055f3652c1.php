
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="titleBox border-bottom py-4">
                <h3 class="mb-0 achivpFont mb-0 font-weight-bold">Dashboard</h3>
            </div>
        </div>
        <div class="col-md-4 my-3">
            <div class="d-flex justify-content-between shadow align-items-end p-3 flex-wrap h-100">
                <div class="totalUser">
                    <p class="mb-2">Your Alias</p>
                    <p class="mb-0 font-weight-bold"><?php echo e($user->alias); ?></p>
                </div>
                <div class="userStats">
                    <img src="<?php echo e(asset('assets/admin/images/avatar-png.webp')); ?>" class="mw-100" alt="Total Users"
                        width="86px" height="86px">
                </div>
            </div>
        </div>
        <div class="col-md-4 my-3">
            <div class="d-flex justify-content-between shadow align-items-end p-3 flex-wrap h-100">
                <div class="totalUser">
                    <p class="mb-2">Total Earning</p>
                    <p class="mb-0 font-weight-bold">
                        <?php $__currentLoopData = $combinedArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key == auth()->user()->id): ?>
                                <?php
                                    echo '$' . array_sum($item);
                                ?>
                            <?php else: ?>
                                <?php continue; ?>;
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
                <div class="userStats">
                    <img src="<?php echo e(asset('assets/admin/images/data-analysis.png')); ?>" class="mw-100" alt="Total Businesses">
                </div>
            </div>
        </div>
        <div class="col-md-4 my-3">
            <div class="d-flex justify-content-between shadow align-items-end p-3 flex-wrap h-100">
                <div class="totalUser">
                    <p class="mb-2">Payment Default</p>
                    <p class="mb-0 font-weight-bold"><?php echo e($user->non_payment_count); ?></p>
                </div>
                <div class="userStats">
                    <img src="<?php echo e(asset('assets/admin/images/graphBox.png')); ?>" class="mw-100" alt="Total Badges">
                </div>
            </div>
        </div>
    </div>

    <!-- No. Students Registered -->
    

    <!-- Recent Subscription -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.user-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sq\resources\views/user/dashboard/dashboard.blade.php ENDPATH**/ ?>