<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="titleBox border-bottom py-4">
                <h3 class="mb-0 achivpFont mb-0 font-weight-bold">Dashboard</h3>
            </div>

            
            <h3>Auto Generate Board</h3>
            <div class="col-md-4 mt-4 d-none" id="successAlert">
                <div class="alert alert-success" role="alert">
                    Status Update Successfully
                </div>
            </div>
            <div class="d-flex">

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="exampleRadios" id="on" value="1" <?php echo e($set_job->status == 1 ? 'checked' : ''); ?>/>
                    <label class="form-check-label" for="on">
                        On
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="exampleRadios" id="off" value="0" <?php echo e($set_job->status == 0 ? 'checked' : ''); ?>/>
                    <label class="form-check-label" for="off">
                        Off
                    </label>
                </div>

            </div>

        </div>
        <div class="col-md-4 my-3">
            <div class="d-flex justify-content-between shadow align-items-end p-3 flex-wrap h-100">
                <div class="totalUser">
                    <p class="mb-2">Total Users</p>
                    <p class="mb-0 font-weight-bold"><?php echo e(count($users)); ?></p>
                </div>
                <div class="userStats">
                    <img src="<?php echo e(asset('assets/admin/images/avatar-png.webp')); ?>" class="mw-100" alt="Total Users"
                        width="86px" height="86px">
                </div>
            </div>
        </div>
        <div class="col-md-4 my-3">
            <div class="d-flex justify-content-between shadow align-items-end p-3 flex-wrap h-100">
                <div class="totalUser">
                    <p class="mb-2">Total Earning</p>
                    <p class="mb-0 font-weight-bold">$100</p>
                </div>
                <div class="userStats">
                    <img src="<?php echo e(asset('assets/admin/images/data-analysis.png')); ?>" class="mw-100" alt="Total Businesses">
                </div>
            </div>
        </div>
        <div class="col-md-4 my-3">
            <div class="d-flex justify-content-between shadow align-items-end p-3 flex-wrap h-100">
                <div class="totalUser">
                    <p class="mb-2">Total Games</p>
                    <p class="mb-0 font-weight-bold">100</p>
                </div>
                <div class="userStats">
                    <img src="<?php echo e(asset('assets/admin/images/graphBox.png')); ?>" class="mw-100" alt="Total Badges">
                </div>
            </div>
        </div>
    </div>

    <!-- No. Students Registered -->
    <div class="badge-section shadow rounded-15 my-4 p-3">
        <div class="row position-relative my-4">
            <div class="col-md-12">
                <div class="col-md-12">
                    <div class="d-flex align-items-center flex-wrap justify-content-between">
                        <div class="graphTitle flex-shrink-0">
                            <h6 class="mb-0 achivpFont">Amount Analytics</h6>
                        </div>
                        <div class="grapSelect d-flex gap-15 flex-shrink-0 flex-wrap flex-lg-nowrap">
                            <select class="form-select form-select-sm pr-5 py-2" aria-label=".form-select-sm example">
                                <option selected>Type</option>
                                <option value="1">January</option>
                                <option value="2">Febuary</option>
                                <option value="3">March</option>
                            </select>
                            <select class="form-select form-select-sm pr-5 py-2" aria-label=".form-select-sm example">
                                <option selected>Month</option>
                                <option value="1">January</option>
                                <option value="2">Febuary</option>
                                <option value="3">March</option>
                            </select>
                        </div>
                    </div>
                    <div class="graphBox py-4 position-relative">
                        <div class="col rotateText">
                            <h6 class="mb-0 achivpFont">Amount</h6>
                        </div>
                        <!--<figure class="mb-0">-->
                        <!--    <img src="../images/graph.png" class="mw-100" alt="No. Students Registered">-->
                        <!--</figure>-->
                        <div id="chartContainer1" style="height: 370px; width: 100%;"></div>
                    </div>
                </div>
                <div class="col-md-12 text-center my-4">
                    <p class="py-3 mb-0">Year</p>
                </div>
            </div>


        </div>
    </div>

    <!-- Recent Subscription -->

    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Recent Members</h3>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No.</th>
                            <th class="table-site-headings">Full Name</th>
                            <th class="table-site-headings">Alias</th>
                            <th class="table-site-headings">Email Address</th>
                            <th class="table-site-headings">Date</th>
                            <th class="table-site-headings">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            use Carbon\Carbon;

                        ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php

                                $currentDate = Carbon::now();
                            ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->alias); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($currentDate->format('Y-m-d')); ?></td>
                                
                                
                                <td class="border-0 font-weight-bold">
                                    <span
                                        class="<?php echo e($user->status == 1 ? 'text-success' : 'text-danger'); ?>"><?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');

            $( "input[name=exampleRadios]:radio" ).on('change' , function(e){
                e.preventDefault();
                console.log($(this).val());

                let url = "<?php echo e(route('admin.set.jobs')); ?>";
                let data = {
                    '_token' : '<?php echo e(csrf_token()); ?>',
                    'status' : $(this).val(),
                }

                let res = AjaxRequest(url , data);
                if(res.status){
                    $('#successAlert').removeClass('d-none');
                    setTimeout(() => {
                        $('#successAlert').addClass('d-none');
                    }, 3000);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\office_work\square_junkie\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>