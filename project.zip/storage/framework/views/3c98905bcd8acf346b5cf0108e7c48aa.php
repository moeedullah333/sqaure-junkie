<!Doctype html>
<html>
<head>
	<title>Square Junkie</title>
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="<?php echo e(asset('assets/website/images/favicon.png')); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
    <?php echo $__env->make('website.layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php
        $request_url = Request::segment(1);
    ?>
    
    <?php if($request_url != 'register' && $request_url != 'user-login' && $request_url !=""): ?>
        <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    
    <?php echo $__env->yieldContent('content'); ?>
    
    <?php if($request_url != 'register' && $request_url != 'user-login' && $request_url !=""): ?>
        <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php echo $__env->make('website.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/website/layouts/main.blade.php ENDPATH**/ ?>