
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Boards</h3>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12 mb-3">
                <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(\Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-between">
            <div class="d-flex justify-content-end">
                <a href="<?php echo e(route('admin.board_create')); ?>" class="btn btn-primary btn-sm">Add Board</a>

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal">
                    Master Button
                </button>
                
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Archive All</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-center">Are You sure you want to archive all boards.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <a href="<?php echo e(route('admin.board_archive_all')); ?>" class="btn btn-danger btn-sm">Archive All</a>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No</th>
                            <th class="table-site-headings">Voting Board Name</th>
                            <th class="table-site-headings">VOTING DEADLINE (DATE)</th>
                            <th class="table-site-headings">GAME DATE (DATE)</th>
                            <th class="table-site-headings">Voter's Choice</th>
                            
                            <th class="table-site-headings">STATUS</th>
                            <th class="table-site-headings">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 1;
                        ?>

                        <?php if($boards->isNotEmpty()): ?>
                            <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($board->board_name); ?></td>
                                    <td><?php echo e($board->voting_deadline); ?></td>
                                    <td><?php echo e($board->game_date); ?></td>
                                    <td>
                                        
                                        <?php if(isset($board->winning_board)): ?>
                                            <?php
                                                $data = json_decode($board->winning_board);
                                            ?>
                                            <?php if(isset($data)): ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    

                                                    <?php if($list == 'ten'): ?>

                                                        <?php if(checkBoardExist($board->id, 10) == true): ?>
                                                            <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '10'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($board->id, 10, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $10 </a>
                                                        <?php endif; ?>
                                                        
                                                    <?php elseif($list == 'twenty'): ?>

                                                        <?php if(checkBoardExist($board->id, 20) == true): ?>
                                                            <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '20'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($board->id, 20, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $20 </a>
                                                        <?php endif; ?>

                                                    <?php elseif($list == 'thirty'): ?>

                                                        <?php if(checkBoardExist($board->id, 30) == true): ?>
                                                            <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '30'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($board->id, 30, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $30 </a>
                                                        <?php endif; ?>

                                                    <?php elseif($list == 'fourty'): ?>

                                                        <?php if(checkBoardExist($board->id, 40) == true): ?>
                                                            <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '40'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($board->id, 40, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $40 </a>
                                                        <?php endif; ?>

                                                    <?php elseif($list == 'fifty'): ?>
                                                    
                                                        <?php if(checkBoardExist($board->id, 50) == true): ?>
                                                            <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '50'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($board->id, 50, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $50 </a>
                                                        <?php endif; ?>

                                                    <?php elseif($list == 'others'): ?>

                                                    <?php if(checkBoardExist($board->id, $board->other_value) == true): ?>
                                                    
                                                            <?php if(isset($board->other_value)): ?>
                                                                <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => $board->other_value])); ?>"
                                                                    class="btn <?php echo e(findSquareCount($board->id, $board->other_value, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                    $<?php echo e($board->other_value); ?> </a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        

                                    </td>

                                    

                                    <?php if($board->status == 1): ?>
                                        <td class="border-0 font-weight-bold">
                                            <span class="text-success">Active</span>
                                        </td>
                                    <?php else: ?>
                                        <td class="border-0 font-weight-bold">
                                            <span class="text-danger">Inactive</span>
                                        </td>
                                    <?php endif; ?>

                                    <td>

                                        <?php if($setJob->status == 0): ?>
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary setCustomBoardPart"
                                                data-toggle="modal" data-id="<?php echo e($board->id); ?>"
                                                data-target="#createCustomBoardPart<?php echo e($board->id); ?>">
                                                Create Board Manually
                                            </button>
                                        <?php endif; ?>

                                        <a href="<?php echo e(route('admin.board_edit', $board->id)); ?>"
                                            class="btn btn-sm btn-primary">Edit</a>

                                        

                                        <button type="button" class="btn btn-sm archiveBoard btn-danger"
                                            data-id="<?php echo e($board->id); ?>">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

            <!-- Modal -->
            <div class="modal fade createCustomBoardPartBody" id="" tabindex="-1" role="dialog"
                aria-labelledby="createCustomBoardPartLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="createCustomBoardPartLabel">Create Board Manually</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" id="boardPartBodyModal">

                        </div>
                        
                    </div>
                </div>
            </div>


            
            <!-- Modal -->
            <div class="modal fade ArchiveModalBody" id="" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Archive</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <P class="text-center">Are you sure you want to archive this board?</P>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <a href="" id="ArchiveButtonAnchor" class="btn btn-danger">Archive</a>
                        </div>
                    </div>
                </div>
            </div>
            


        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');

            $(document).on('click', '.setCustomBoardPart', function(e) {
                // console.log('yes')
                e.preventDefault();
                let data = $(this).data('id');
                let id = 'createCustomBoardPart' + data;
                $(".createCustomBoardPartBody").attr("id", id);
                $('#' + id).modal('show');
                create_board(data)
                // $("#ArchiveButtonAnchor").attr("href", url);
            });


            function create_board(id) {
                $('#boardPartBodyModal').empty();

                let url = "<?php echo e(route('admin.boardPartData')); ?>";

                let data = {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'id': id,
                }

                let res = AjaxRequest(url, data);

                if (res.status == true) {

                    console.log(res.data);
                    console.log(JSON.parse(res.data.winning_board));

                    if (JSON.parse(res.data.winning_board) !== null) {

                        JSON.parse(res.data.winning_board).forEach(element => {

                            $('#boardPartBodyModal').append(` 
                                <button class="btn btn-primary manualBoard" data-element="${element}" data-board_id="${res.data.id}" > ${element == 'others' ? `Others ($${res.data.other_value})`  : element }  </button>
                            `);
                        });
                    } else {
                        $('#boardPartBodyModal').html(`
                                <p class="text-center">Data Not Availabe.</p>
                            `);
                    }


                }
                console.log(res);
            }


            $(document).on('click', '.manualBoard', function(e) {
                e.preventDefault();
                if (confirm('Yor you sure you want to create this board')) {
                    console.log($(this).data('element'))

                    let url = "<?php echo e(route('admin.add.board.part.manual')); ?>";
                    let data = {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'id': $(this).data('board_id'),
                        'data': $(this).data('element'),
                    }
                    let res = AjaxRequest(url, data);
                    // console.log(res);
                    if (res.status == true) {
                        alert('Board create successfully');
                        location.reload();
                    } else {
                        alert(res.msg);
                    }
                }
            });

            $(document).on('click', '.archiveBoard', function(e) {
                e.preventDefault();
                let data = $(this).data('id');
                let id = 'exampleModal' + data;
                $(".ArchiveModalBody").attr("id", id);
                let url = "<?php echo e(route('admin.board_archive', ':id')); ?>";
                url = url.replace(':id', data);
                $("#ArchiveButtonAnchor").attr("href", url);
                $('#' + id).modal('show');
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\office_work_2\square_junkie\resources\views/admin/board/index.blade.php ENDPATH**/ ?>