<link rel="icon" type="image/x-icon" href="/">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;0,700;0,900;1,800;1,900&family=Noto+Naskh+Arabic&family=Poppins:ital,wght@0,200;0,400;0,500;0,600;0,700;1,200;1,300&display=swap"
    rel="stylesheet">
<link type="text/css" rel="stylesheet" href="../css/image-uploader.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/main.css')); ?>" type="text/css">
<link rel="stylesheet" href="//cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
<?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/user/user-layout/css.blade.php ENDPATH**/ ?>