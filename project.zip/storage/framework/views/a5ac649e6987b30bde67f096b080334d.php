

<?php $__env->startSection('content'); ?>
    <section class="immersive_gameplay_section">
        <div class="container">
            <div class="row">

                <img src="<?php echo e(asset('assets/new_website/images/empty-logo.png')); ?>" class="empty-logo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/right-blogo.png')); ?>" class="right-blogo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/c-logo.png')); ?>" class="c-logo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/s-logo.png')); ?>" class="sm-slogo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/b-logo.png')); ?>" class="b-logo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/s-logo.png')); ?>" class="second_slogo" alt="">

                <img src="<?php echo e(asset('assets/new_website/images/a-S-logo.png')); ?>" class="first_slogo" alt="">

                <div class="col-md-8 mx-auto">
                    <h2 class="main_heading text-center">board parts list</h2>

                    <!-- <p class="main_para text-center">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
                                </p> -->

                    <!-- <div class="main_action_btn text-center mt-3">
                                    <a href="javascript:;">PLAY NOW</a>
                                </div> -->

                </div>


                <?php if (isset($component)) { $__componentOriginale879b590e7465e1b7997c63670a370ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale879b590e7465e1b7997c63670a370ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale879b590e7465e1b7997c63670a370ad)): ?>
<?php $attributes = $__attributesOriginale879b590e7465e1b7997c63670a370ad; ?>
<?php unset($__attributesOriginale879b590e7465e1b7997c63670a370ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale879b590e7465e1b7997c63670a370ad)): ?>
<?php $component = $__componentOriginale879b590e7465e1b7997c63670a370ad; ?>
<?php unset($__componentOriginale879b590e7465e1b7997c63670a370ad); ?>
<?php endif; ?>

            </div>
        </div>

    </section>


    <section class="board_parts_list_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="main_heading text-center mb-4">board parts list</h2>
                </div>
            </div>

            <div class="row customized_row">
                <div class="col-md-12 customized_column">
                    <h4 class="board_number_heading" id="board_name"></h4>
                </div>

                <?php if(count($gameBoard) > 0): ?>
                    <?php $__currentLoopData = $gameBoard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="col-md-4 mb-3">
                            <input type="hidden" value="<?php echo e($list->boardName->board_name); ?>" id="board_name<?php echo e($key); ?>">
                            <div class="board_part_detail_card counterBox" id="box_count_<?php echo e($key); ?>">
                                <p>PART <?php echo e($list->part); ?></p>
                                <p class="card-title">Square Select: <span id="box_count" class="db_count"><?php echo e($count[$key]); ?></span></p>
                                <p>Your Square Buy: <span class="db_count"><?php echo e($countUserSquareBuy[$key]); ?></span></p>
                                <span>Board Price: $<?php echo e($list->price); ?></span>

                                <div class="main_action_btn mt-3">
                                    
                                    <button class="text-dark btn" type="button" disabled
                                        onclick="window.location.href = '<?php echo e(route('user.board', ['part' => $list->part, 'id' => $list->id, 'board_id' => $list->board_id, 'price' => $list->price])); ?>'">View
                                        Board</button>
                                </div>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>No boards available.</p>
                <?php endif; ?>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>

jQuery(document).ready(function() {
// let boardName = jQuery('div#board_name0').val();
        //     let boardName = jQuery('#board_name0').val();
        let boardName = jQuery('#board_name0').val();
            $('#board_name').text(boardName);
jQuery('div#box_count_0 button').removeAttr('disabled');
jQuery('.counterBox').each(function(index) {
    
    let countValue = jQuery(`#box_count_${index}`).find('.card-title #box_count').text();
    console.log(countValue,index);

    if (countValue == 100) {
        jQuery(this).parents('.col-md-4').next().find('button').removeAttr('disabled');
    }

})
});

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('new_website.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sq\resources\views/new_website/pages/board_part_list.blade.php ENDPATH**/ ?>