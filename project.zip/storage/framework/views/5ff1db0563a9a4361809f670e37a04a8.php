
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Current Games List</h3>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12 mb-3">
                <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(\Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No</th>
                            <th class="table-site-headings">Voting Board Name</th>
                            <th class="table-site-headings">VOTING DEADLINE (DATE)</th>
                            <th class="table-site-headings">GAME DATE (DATE)</th>
                            <th class="table-site-headings">STATUS</th>
                            <th class="table-site-headings">Square Selection</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 1;

                        ?>

                        <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            

                            <tr>

                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($list->board_name); ?></td>
                                <td><?php echo e($list->voting_deadline); ?></td>
                                <td><?php echo e($list->game_date); ?></td>
                                <?php if($list->status == 1): ?>
                                    <td class="border-0 font-weight-bold">
                                        <span class="text-success">Active</span>
                                    </td>
                                <?php else: ?>
                                    <td class="border-0 font-weight-bold">
                                        <span class="text-danger">Inactive</span>
                                    </td>
                                <?php endif; ?>

                                <td>

                                    <?php if($list->winning_board != null && $list->winning_board != '[]'): ?>
                                        <?php if(isset($list->winning_board)): ?>
                                            <?php
                                                $data = json_decode($list->winning_board);
                                            ?>
                                            <?php if(isset($data)): ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listBoardNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($listBoardNum == 'ten'): ?>
                                                        <?php if(checkBoardExist($list->id, 10) == true): ?>
                                                            <a href="<?php echo e(route('user.boardPart.list', ['id' => $list->id, 'price' => '10'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($list->id, 10, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $10 </a>
                                                        <?php endif; ?>
                                                    <?php elseif($listBoardNum == 'twenty'): ?>
                                                        <?php if(checkBoardExist($list->id, 20) == true): ?>
                                                            <a href="<?php echo e(route('user.boardPart.list', ['id' => $list->id, 'price' => '20'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($list->id, 20, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $20 </a>
                                                        <?php endif; ?>
                                                    <?php elseif($listBoardNum == 'thirty'): ?>
                                                        <?php if(checkBoardExist($list->id, 30) == true): ?>
                                                            <a href="<?php echo e(route('user.boardPart.list', ['id' => $list->id, 'price' => '30'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($list->id, 30, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $30 </a>
                                                        <?php endif; ?>
                                                    <?php elseif($listBoardNum == 'fourty'): ?>
                                                        <?php if(checkBoardExist($list->id, 40) == true): ?>
                                                            <a href="<?php echo e(route('user.boardPart.list', ['id' => $list->id, 'price' => '40'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($list->id, 40, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $40 </a>
                                                        <?php endif; ?>
                                                    <?php elseif($listBoardNum == 'fifty'): ?>
                                                        <?php if(checkBoardExist($list->id, 50) == true): ?>
                                                            <a href="<?php echo e(route('user.boardPart.list', ['id' => $list->id, 'price' => '50'])); ?>"
                                                                class="btn <?php echo e(findSquareCount($list->id, 50, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                $50 </a>
                                                        <?php endif; ?>
                                                    <?php elseif($listBoardNum == 'others'): ?>
                                                        <?php if(checkBoardExist($list->id, $list->other_value) == true): ?>
                                                            <?php if(isset($list->other_value)): ?>
                                                                <a href="<?php echo e(route('user.boardPart.list', ['id' => $list->id, 'price' => $list->other_value])); ?>"
                                                                    class="btn <?php echo e(findSquareCount($list->id, $list->other_value, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                                    $<?php echo e($list->other_value); ?> </a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('voting', $list->id)); ?>" class="btn btn-warning">Go to
                                            Voting</a>
                                    <?php endif; ?>


                                    

                                </td>

                                
                                
                                
                                
                                

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                    </tbody>
                </table>
            </div>

            
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.user-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/user/boxbuy/current_game_list.blade.php ENDPATH**/ ?>