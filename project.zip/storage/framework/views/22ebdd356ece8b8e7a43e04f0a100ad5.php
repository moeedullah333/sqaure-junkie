<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/font-awesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/responsive.css')); ?>" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php echo $__env->yieldPushContent('css'); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/website/layouts/style.blade.php ENDPATH**/ ?>