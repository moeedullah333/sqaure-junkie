<form action="<?php echo e(route('user.contact')); ?>" method="post" class="mt-3">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <input type="text" class="form-control" id="" name="name"
            placeholder="First Name*">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <input type="email" class="form-control" id="" aria-describedby="emailHelp"
            name="email" placeholder="Your Email*">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <input type="number" class="form-control" id="" aria-describedby="emailHelp"
            name="phone" placeholder="Phone Number*">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <textarea class="form-control" id="" rows="6" name="msg" placeholder="Your Message...."></textarea>
    </div>

    <div class="main_action_btn mt-3 mx-auto">
        <button class="form_submit_btn w-100 btn" type="submit" class="w-100 text-center">SUBMIT
            NOW</button>
        <!--<a href="javascript:;" >SUBMIT NOW</a>-->
    </div>

</form><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/components/contact-form.blade.php ENDPATH**/ ?>