
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Boards <span id="board_name"></span></h3>
            </div>
        </div>



        
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(\Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <div class="row">   
            <div class="col-md-12 pt-5 table-responsive">

                <div class="col-md-12">
                    <div class="row">
                        <?php if($data->isNotEmpty()): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" value="<?php echo e($list->boardName->board_name); ?>"
                                    id="board_name<?php echo e($key); ?>">
                                <div class="col-md-3 mb-5">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title text-capitalize">Part : <?php echo e($list->part); ?></h5>
                                            <h6 class="card-subtitle mb-2 text-muted">Price : <?php echo e($list->price); ?></h6>
                                            <a class="btn btn-primary"
                                                href="<?php echo e(route('admin.game.board', ['part' => $list->part, 'board_id' => $list->board_id, 'id' => $list->id, 'price' => $list->price])); ?>"
                                                class="card-link">View Board</a>

                                            <?php if($list->block_board == 1): ?>
                                                <a class="btn btn-warning"
                                                    href="<?php echo e(route('admin.game.board.block.unblock', ['part' => $list->part, 'board_id' => $list->board_id, 'id' => $list->id, 'price' => $list->price, 'status' => 0])); ?>"
                                                    class="card-link">Unblock Board</a>
                                            <?php else: ?>
                                                <a class="btn btn-danger"
                                                    href="<?php echo e(route('admin.game.board.block.unblock', ['part' => $list->part, 'board_id' => $list->board_id, 'id' => $list->id, 'price' => $list->price, 'status' => 1])); ?>"
                                                    class="card-link">Block Board</a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="col-md-3 mb-5">
                                <div class="card">
                                    <div class="card-body">
                                        <p>This board is having votes under 100.</p>
                                        <br>
                                        <?php if($part !== null): ?>
                                        <a class="btn btn-danger"
                                        href="<?php echo e(route('admin.board_remove_empty', ['part' => $part, 'id' => $id ])); ?>"
                                        class="card-link">Remove This Board</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

                </div>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let boardName = jQuery('#board_name0').val();
            $('#board_name').text(boardName);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custom3mystaging/public_html/square_junkie/resources/views/admin/game-board/board-list.blade.php ENDPATH**/ ?>