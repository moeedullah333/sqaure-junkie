
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Others Boards List</h3>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12 mb-3">
                <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(\Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        


        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No</th>
                            <th class="table-site-headings">Voting Board Name</th>
                            <th class="table-site-headings">VOTING DEADLINE (DATE)</th>
                            <th class="table-site-headings">Total Vote Count</th>
                            <th class="table-site-headings">Average Price</th>
                            <th class="table-site-headings">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 1;
                        ?>

                        
                        <?php $__currentLoopData = $baordsGet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($count++); ?></td>
                                <td><?php echo e($board['board_name']); ?></td>
                                <td><?php echo e($board['voting_deadline']); ?></td>
                                <td><?php echo e(count(json_decode($board['others']))); ?></td>
                                <td>
                                    <?php
                                        $boardPriceArr = [];
                                        foreach ($board['other_board'] as $key => $value) {
                                            $boardPriceArr[] = (int) $value['price'];
                                        }
                                        $average_value = array_sum($boardPriceArr) / count($boardPriceArr);
                                        echo '$' . round($average_value);
                                    ?>
                                </td>



                                <td>
                                    <a href="<?php echo e(route('other.board.user.vote.list', $board['id'])); ?>"
                                        class="btn btn-primary btn-sm">View Users</a>


                                    <!-- Button trigger modal -->
                                    <?php if($board['other_value'] != null): ?>
                                        <button type="button" class="btn set-board-price" disabled data-toggle="modal"
                                            data-target="#exampleModalSetBoardPrice<?php echo e($board['id']); ?>"
                                            data-id="<?php echo e($board['id']); ?>">
                                            Already Selected Price
                                        </button>
                                    <?php else: ?>
                                        <button type="button"
                                            class="btn set-board-price <?php echo e(count(json_decode($board['others'])) < 100 ? 'btn-secondary' : 'btn-primary'); ?> "
                                            <?php echo e(count(json_decode($board['others'])) < 100 ? 'disabled' : ''); ?>

                                            data-toggle="modal" data-target="#exampleModalSetBoardPrice<?php echo e($board['id']); ?>"
                                            data-id="<?php echo e($board['id']); ?>">
                                            set price
                                        </button>
                                    <?php endif; ?>

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                    </tbody>
                </table>
            </div>

            <!-- Modal -->
            <div class="modal fade setPriceModal" id="" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalSetBoardPriceLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalSetBoardPriceLabel">Set Price</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Set Price</label>
                                <input type="text" class="form-control" name="setPrice" id="setPrice"
                                    placeholder="Enter Price">

                                <span class="text-danger" id="setPriceError"></span>
                            </div>

                            <input type="hidden" name="board_id" id="board_id" class="form-control">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" id="setPirce" class="btn btn-primary">Set Price</button>
                        </div>
                    </div>
                </div>
            </div>

            
            <!-- Modal -->
            

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');


            $('#setPirce').on('click', function(e) {
                e.preventDefault();

                let priceValue = $('#setPrice').val();
                let board_id = $('#board_id').val();

                if (priceValue != "") {

                    let data = {
                        '_token': '<?php echo e(csrf_token()); ?>',
                        'price': priceValue,
                        'board_id': board_id,
                    }

                    let url = "<?php echo e(route('other.board.price.set')); ?>";

                    let res = AjaxRequest(url, data);

                    if (res.status == true) {
                        alert(res.msg);
                        location.reload();
                    }

                    $('#setPriceError').text('');
                } else {
                    $('#setPriceError').text('Enter value set price field.');
                }
            })

            $('.set-board-price').on('click', function(e) {

                e.preventDefault();
                let data = $(this).data('id');
                let id = 'exampleModalSetBoardPrice' + data;
                $(".setPriceModal").attr("id", id);
                $("#board_id").val(data);

            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/admin/others/index.blade.php ENDPATH**/ ?>