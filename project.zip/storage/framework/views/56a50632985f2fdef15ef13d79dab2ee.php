

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">

                <div class="profile_form_div">
                    <div>
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success mb-4" id="success-alert">
                                <center><span class="text-dark"><?php echo e(Session::get('message')); ?></span></center>
                            </div>
                        <?php endif; ?>
                    </div>
                    <form action="<?php echo e(route('update.user.details')); ?>" method="POST" enctype="multipart/form-data"
                        class="">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="profile-badge">


                            <div class="profile-pic">

                                <img class="img-circle"
                                    src="<?php echo e(Auth::user()->avatar != '' ? asset(Auth::user()->avatar) : asset('assets/admin/images/user-icon.png')); ?>"
                                    id="profile-image1" alt="Upload Image" title="Upload Image" />

                            </div>

                            <div class="row mb-md-4 user-detail">
                                <div class="col-md-6">
                                    <label for="title">Name </label>
                                    <input type="text" class="form-control" name="name" placeholder=""
                                        value="<?php echo e($userDetail->name); ?>">
                                </div>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="col-md-6">
                                    <label for="title">Email Address </label>
                                    <input type="email" class="form-control" name="email" placeholder=""
                                        value="<?php echo e($userDetail->email); ?>">
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="col-md-6 mt-3">
                                    <label for="title">Alias </label>
                                    <input type="text" class="form-control" name="alias"
                                        placeholder="Your Alias Here!!" value="<?php echo e($userDetail->alias); ?>">
                                </div>
                                <div class="col-md-6  mt-3">
                                    <label for="title">HashTag </label>
                                    <input type="text" class="form-control" name="hashtag" placeholder="Add Your HashTag"
                                        value="<?php echo e($userDetail->hashtag); ?>" required>
                                </div>
                                <div class="col-md-6  mt-3">
                                    <label for="title">Upload Profile Image </label>
                                    <input type="file" class="form-control" name="avatar">
                                </div>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <div class="col-md-6  mt-3">
                                    <label for="title">Phone Number</label>
                                    <input type="number" class="form-control" value="<?php echo e($userDetail->number); ?>"
                                        name="phone">
                                </div>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="error text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="my-4 register-buttons d-flex justify-content-end">
                                <button class="btn btn-pill " type="submit">Update Profile</button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.user-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custom3mystaging/public_html/square_junkie/resources/views/user/detail/user_profile.blade.php ENDPATH**/ ?>