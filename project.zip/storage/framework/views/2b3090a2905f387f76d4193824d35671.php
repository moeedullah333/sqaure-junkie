
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Archive Boards</h3>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12 mb-3">
                <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(\Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>


        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No</th>
                            <th class="table-site-headings">Voting Board Name</th>
                            <th class="table-site-headings">VOTING DEADLINE (DATE)</th>
                            <th class="table-site-headings">GAME DATE (DATE)</th>
                            <th class="table-site-headings">Voter's Choice</th>
                            <th class="table-site-headings">Square Selection </th>
                            <th class="table-site-headings">Payment Status</th>
                            <th class="table-site-headings">STATUS</th>
                            <th class="table-site-headings">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 1;
                        ?>

                        <?php if($boards->isNotEmpty()): ?>
                            <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($board->board_name); ?></td>
                                    <td><?php echo e($board->voting_deadline); ?></td>
                                    <td><?php echo e($board->game_date); ?></td>
                                    <td>
                                        
                                        <?php if(isset($board->winning_board)): ?>
                                            <?php
                                                $data = json_decode($board->winning_board);
                                            ?>
                                            <?php if(isset($data)): ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <?php if($list == 'ten'): ?>
                                                        <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '10'])); ?>"
                                                            class="btn <?php echo e(findSquareCount($board->id, 10, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                            $10 </a>
                                                    <?php elseif($list == 'twenty'): ?>
                                                        <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '20'])); ?>"
                                                            class="btn <?php echo e(findSquareCount($board->id, 20, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                            $20 </a>
                                                    <?php elseif($list == 'thirty'): ?>
                                                        <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '30'])); ?>"
                                                            class="btn <?php echo e(findSquareCount($board->id, 30, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                            $30 </a>
                                                    <?php elseif($list == 'fourty'): ?>
                                                        <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '40'])); ?>"
                                                            class="btn <?php echo e(findSquareCount($board->id, 40, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                            $40 </a>
                                                    <?php elseif($list == 'fifty'): ?>
                                                        <a href="<?php echo e(route('admin.game.board.list', ['id' => $board->id, 'price' => '50'])); ?>"
                                                            class="btn <?php echo e(findSquareCount($board->id, 50, $boardsSquareCount) ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                                                            $50 </a>
                                                        
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        

                                    </td>

                                    <td>
                                        <?php
                                            if (isset($squareBuy[$board->id])) {
                                                foreach ($squareBuy[$board->id] as $partKey => $part) {
                                                    if (!empty($part)) {
                                                        foreach ($part as $squareKey => $squareCount) {
                                                            $partClass = 'btn btn-secondary';

                                                            if ($squareCount[0]['squaresCount'] == 100) {
                                                                $partClass = 'btn btn-primary';
                                                            }

                                                            echo '<a href="#" style="margin-right:10px;" class="btn ' . $partClass . '"> ' . $squareKey . $partKey . '  </a>';
                                                        }
                                                    }
                                                }
                                            }
                                        ?>
                                    </td>


                                    <td>
                                        <?php
                                            if (isset($squareBuy[$board->id])) {
                                                foreach ($squareBuy[$board->id] as $partKey => $part) {
                                                    if (!empty($part)) {
                                                        foreach ($part as $squareKey => $squareCount) {
                                                            $partClass = 'btn btn-secondary';

                                                            if ($squareCount[0]['paymentsCount'] == 100) {
                                                                $partClass = 'btn btn-primary';
                                                            }

                                                            echo '<a href="#" style="margin-right:10px;" class="btn ' . $partClass . '"> ' . $squareKey . $partKey . '  </a>';
                                                        }
                                                    }
                                                }
                                            }
                                        ?>
                                    </td>

                                    <?php if($board->status == 1): ?>
                                        <td class="border-0 font-weight-bold">
                                            <span class="text-success">Active</span>
                                        </td>
                                    <?php else: ?>
                                        <td class="border-0 font-weight-bold">
                                            <span class="text-danger">Inactive</span>
                                        </td>
                                    <?php endif; ?>

                                    <td>
                                        <a href="<?php echo e(route('admin.board_edit', $board->id)); ?>"
                                            class="btn btn-sm btn-primary">Edit</a>

                                        

                                        <button type="button" class="btn btn-sm ongoingBoard btn-danger"
                                            data-id="<?php echo e($board->id); ?>">ongoing</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

             
            <!-- Modal -->
            <div class="modal fade ongoingModalBody" id="" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">ongoing</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <P class="text-center">Are you sure you want to ongoing this board?</P>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <a href="" id="ongoingButtonAnchor" class="btn btn-danger">Ongoing</a>
                        </div>
                    </div>
                </div>
            </div>
            

            

            


        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');

            $(document).on('click', '.ongoingBoard', function(e) {
                e.preventDefault();
                let data = $(this).data('id');
                let id = 'exampleModal' + data;
                $(".ongoingModalBody").attr("id", id);
                let url = "<?php echo e(route('admin.archive-baord-ongoing', ':id')); ?>";
                url = url.replace(':id', data);
                $("#ongoingButtonAnchor").attr("href", url);
                $('#' + id).modal('show');
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/admin/archive/index.blade.php ENDPATH**/ ?>