
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Number Generation Boards</h3>
            </div>
        </div>

        <style>
            .fisco_y span {
                border: 1px solid #979797;
                padding: 5px;
                border-radius: 5px
            }
        </style>
        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No.</th>
                            <th class="table-site-headings">Board Name</th>
                            <th class="table-site-headings">Generate Number Date</th>
                            <th class="table-site-headings">Voter's Choice</th>
                            <th class="table-site-headings">Payment</th>
                            <th class="table-site-headings">Number Generated</th>
                            <th class="table-site-headings">Action</th>

                        </tr>
                    </thead>
                    <tbody>

                        <?php
                            $count = 1;
                        ?>
                        <?php $__currentLoopData = $boardList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $board->gameBoardShowPart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->delete_status == 1): ?>
                                    <?php continue; ?>;
                                <?php endif; ?>
                                <tr id="tr_">
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($board->board_name); ?></td>
                                    <td><?php echo e($board->generate_number); ?></td>
                                    
                                    <td>
                                        <?php
                                            $route = Crypt::encrypt('admin.number.generation.list');
                                        ?>

                                        <?php if($board->status == 1 && checkPayments($board->id, $item->part, $item->price)): ?>
                                            <a class="btn btn-success btn-sm"
                                                href="<?php echo e(route('admin.game.board', [$item->part, $board->id, $item->id, $item->price])); ?>?num-gen=<?php echo e($route); ?>">
                                                <?php echo e($item->price); ?> <?php echo e($item->part); ?>

                                            </a>
                                        <?php else: ?>
                                            <a class="btn btn-secondary btn-sm"
                                                href="<?php echo e(route('admin.game.board', [$item->part, $board->id, $item->id, $item->price])); ?>?num-gen=<?php echo e($route); ?>">
                                                <?php echo e($item->price); ?> <?php echo e($item->part); ?>

                                            </a>
                                        <?php endif; ?>



                                    </td>
                                    <td>
                                        <?php if($board->status == 1 && checkPayments($board->id, $item->part, $item->price)): ?>
                                            <b class="text-success">Paid</b>
                                        <?php else: ?>
                                            <b class="text-danger">UnPaid</b>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(
                                            ($board->status == 1 && $item->spiner_count == 0 && $item->spin_numbers == 0) ||
                                               ( $item->spiner_count < $item->spin_numbers)): ?>
                                            <span class="badge badge-pill badge-info">Active</span>
                                        <?php elseif($board->status == 1 && ($item->spiner_count == $item->spin_numbers)): ?>
                                            <span class="badge badge-pill badge-success">Complete</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a class="btn btn-primary btn-sm"
                                            href="<?php echo e(route('admin.board_edit', $board->id)); ?>">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');

            // $('.resetBtn').click(function() {
            //     let userId = $(this).data('user_id');
            //     console.log(userId);
            //     if (confirm('Are you sure you want to reset this user ?')) {
            //         let data = {
            //             ''
            //         };
            //     }

            // });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sq\resources\views/admin/number-generation/index.blade.php ENDPATH**/ ?>