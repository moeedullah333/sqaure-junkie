
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Delete Board Parts</h3>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No.</th>
                            <th class="table-site-headings">Board Name</th>
                            <th class="table-site-headings">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($deleteBoard) > 0): ?>
                            <?php
                                $count = 1;
                            ?>
                            <?php $__currentLoopData = $deleteBoard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($board->board_name); ?></td>
                                    <td class="text-danger">Deleted</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custom3mystaging/public_html/square_junkie/resources/views/admin/delete-board/baords.blade.php ENDPATH**/ ?>