<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Main Database</h3>
            </div>
        </div>

        <style>
            .fisco_y span {
                border: 1px solid #979797;
                padding: 5px;
                border-radius: 5px
            }
        </style>
        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <h4 class="fisco_y text-right">Fisco Year: <span>2024</span></h4>
                <table class="table text-center" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No.</th>
                            <th class="table-site-headings">Full Name</th>
                            <th class="table-site-headings">Alias</th>
                            <th class="table-site-headings">Email Address</th>
                            <th class="table-site-headings">Total Squares</th>
                            <th class="table-site-headings">Total Squares Default</th>
                            <th class="table-site-headings">Total Time Default</th>
                            <th class="table-site-headings">Date</th>
                            <th class="table-site-headings">Status</th>
                            <th class="table-site-headings">Status Ban</th>
                            <th class="table-site-headings">Total Earning</th>
                            <th class="table-site-headings">Action</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                            use Carbon\Carbon;

                        ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $currentDate = Carbon::now();
                            ?>
                            <tr id="tr_<?php echo e($user->id); ?>">
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->alias); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e(count($user->squareBuy)); ?></td>
                                <?php
                                    $usresGet = $user->squareBuy->toArray();
                                    $findColumn = array_column($usresGet, 'delete_status');
                                    $arr = array_count_values($findColumn);
                                ?>

                                <?php if(isset($arr[1])): ?>
                                    <td><?php echo e($arr[1]); ?></td>
                                <?php else: ?>
                                    <td>0</td>
                                <?php endif; ?>

                                <td><?php echo e($user->non_payment_count); ?></td>
                                <td><?php echo e($currentDate->format('Y-m-d')); ?></td>

                                <td class="border-0 font-weight-bold">
                                    <span
                                        class="<?php echo e($user->status == 1 ? 'text-success' : 'text-danger'); ?>"><?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?></span>
                                </td>

                                <td class="border-0 font-weight-bold">
                                    <span
                                        class="<?php echo e($user->ban_user == 1 ? 'text-danger' : 'text-success'); ?>"><?php echo e($user->ban_user == 1 ? 'Ban' : 'Unban'); ?></span>
                                </td>

                                <td class="border-0 font-weight-bold">
                                    <?php $__currentLoopData = $combinedArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if ($key == $user->id) {
                                                echo array_sum($item);
                                            } else {
                                                continue;
                                            }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" id="benUser"
                                        data-user_id="<?php echo e($user->id); ?>"> Ben/Delete </button>
                                    <button class="btn btn-sm btn-warning resetBtn" id="unbenUser"
                                        data-user_id="<?php echo e($user->id); ?>">
                                        Reset </button>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');

            

            $(document).on('click', '#benUser', function() {
            
                let url = "<?php echo e(route('admin.users.ban.ajax')); ?>";
                let data = {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    'user_id': $(this).data('user_id'),
                    'type': 'ban',
                };

                let res = AjaxRequest(url, data);
                if (res.status == true) {
                   alert('User Ban successfully!');
                   location.reload();
                }

            });

            $(document).on('click', '#unbenUser', function() {

                let url = "<?php echo e(route('admin.users.ban.ajax')); ?>";
                let data = {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    'user_id': $(this).data('user_id'),
                    'type': 'unban',
                };

                let res = AjaxRequest(url, data);

                if (res.status == true) {
                   alert('User Unban successfully!');
                   location.reload();
                }

            });
            // $('.resetBtn').click(function() {
            //     let userId = $(this).data('user_id');
            //     console.log(userId);
            //     if (confirm('Are you sure you want to reset this user ?')) {
            //         let data = {
            //             ''
            //         };
            //     }

            // });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/custom3mystaging/public_html/square_junkie/resources/views/admin/users/userList.blade.php ENDPATH**/ ?>