
<?php $__env->startSection('content'); ?>
    <div class="notification-section shadow rounded-15 p-3 pt-5 my-4">
        <div class="row justify-content-between">
            <div class="col-md-12 mb-3">
                <h3 class="achivpFont">Weekly Payment Summary</h3>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3">
                <p>Select Date :</p>
                <select class="form-control" name="" id="date">
                    <option value="all">Select</option>
                    <option value="all">All</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 pt-5 table-responsive">
                <table class="table" id="datatable">
                    <thead>
                        <tr>
                            <th class="table-site-headings">S.No.</th>
                            <th class="table-site-headings">User Name</th>
                            <th class="table-site-headings">Board Name</th>
                            <th class="table-site-headings">Part</th>
                            <th class="table-site-headings">Price</th>
                            <th class="table-site-headings">Total Square</th>
                            <th class="table-site-headings">Total Price</th>
                            <th class="table-site-headings">Status</th>
                        </tr>
                    </thead>
                    <tbody id="payments">
                        <?php if(count($payments) > 0): ?>
                            <?php
                                $count = 1;
                            ?>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($payment->User->name); ?></td>
                                    <td><?php echo e($payment->boardName->board_name); ?></td>
                                    <td><?php echo e($payment->part); ?></td>
                                    <td><?php echo e($payment->price); ?></td>
                                    <td><?php echo e(count(json_decode($payment->total_square))); ?></td>
                                    <td><?php echo e(count(json_decode($payment->total_square)) * $payment->price); ?></td>
                                    <?php if($payment->refund_status == 0): ?>
                                        <td>
                                            <span class="badge badge-pill badge-success">Complete</span>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <span class="badge badge-pill badge-danger">Refund</span>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

    <script>
        $(document).ready(function() {
            let table = new DataTable('#datatable');
        });

        $(document).on('change', '#date', function() {

            $('#payments').empty();

            let html = '';
            console.log($(this).val());
            let url = "<?php echo e(route('admin.users.payment.ajax')); ?>";
            let data = {
                '_token': '<?php echo e(csrf_token()); ?>',
                'type': $(this).val(),
            };

            let res = AjaxRequest(url, data);

            console.log(res);
            if (res.status == true) {
                $('#datatable').dataTable().fnClearTable();
                $('#datatable').dataTable().fnDestroy();


                res.data.forEach((element, index) => {
                    let refund_complete = '';
                    if (element.refund_status == 0) {
                        refund_complete += `
                                        <td>
                                            <span class="badge badge-pill badge-success">Complete</span>
                                        </td>
                                        `;
                    } else {
                        refund_complete += `
                                        <td>
                                            <span class="badge badge-pill badge-danger">Refund</span>
                                        </td>
                                        `;
                    }

                    html += `
                            <tr>
                                <td>${index+1}</td>    
                                <td>${(element.user && element.user.name) ? element.user.name : "" }</td>    
                                <td>${(element.board_name && element.board_name.board_name) ? element.board_name.board_name : ""}</td>    
                                <td>${(element.part) ? element.part :""}</td>    
                                <td>${(element.price) ? element.price : ""}</td>    
                                <td>${(JSON.parse(element.total_square).length) ? JSON.parse(element.total_square).length : ""}</td>    
                                <td>${(JSON.parse(element.total_square).length * element.price) ? JSON.parse(element.total_square).length * element.price : "" } </td>    
                                ${refund_complete} 
                            </tr>
                        `;


                });

                $('#payments').html(html);
                new DataTable('#datatable');
            }
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/admin/payment/index.blade.php ENDPATH**/ ?>