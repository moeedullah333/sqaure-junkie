<?php if(\Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(\Session::get('success')); ?></div>
<?php endif; ?>
<?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/components/success-message.blade.php ENDPATH**/ ?>