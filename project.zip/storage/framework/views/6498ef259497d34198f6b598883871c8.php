
<?php $__env->startSection('content'); ?>
    <style>
        .checkMarkOwn {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            /* cursor: not-allowed; */
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #8FEA9A;
            user-select: none;
        }

        .board_dates_details {
            display: flex;
            justify-content: space-between;
            align-items: center;

        }

        .board_dates_details p {
            color: red;
            font-weight: bold;
        }

        h3.yyy_text {
            transform: rotate(270deg);
        }

        .gamingBox td.yyy_td {
            width: 30px !important;
        }

        h3.yyy_text {
            transform: rotate(270deg);
            position: absolute;
            top: 50%;
            left: -50px;
        }
    </style>

    <?php if(($data->spiner_count !== 0 && $data->spiner_count !== 0 ) && ($data->spiner_count == $data->spin_numbers)): ?>
        <style>
            .new span {
                visibility: visible;
            }

            .firstXnumber span {
                visibility: visible;
            }

            .secondXnumber span {
                visibility: visible;
            }

            .thirdXnumber span {
                visibility: visible;
            }

            .fourthXnumber span {
                visibility: visible;
            }
        </style>
    <?php else: ?>
        <style>
            .new span {
                visibility: hidden;
            }

            .firstXnumber span {
                visibility: hidden;
            }

            .secondXnumber span {
                visibility: hidden;
            }

            .thirdXnumber span {
                visibility: hidden;
            }

            .fourthXnumber span {
                visibility: hidden;
            }
        </style>
    <?php endif; ?>



    <div class="ediTprofile">

        <div class="row">
            <div class="col-md-12">
                <div class="titleBox py-4">
                    <h3 class="achivpFont font-weight-bold mb-0 text-center"><a href="#"
                            class="text-danger text-decoration-none">$<?php echo e($data->price); ?> Board</a></h3>

                    
                </div>
            </div>
        </div>
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(\Session::get('success')); ?></div>
        <?php endif; ?>
        <div class="report-section shadow px-5 py-4 rounded-15 my-4">
            <div class="row justify-content-between align-items-center">
                <div class="col-md-5">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link text-dark active" id="home-tab" data-toggle="tab" data-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">Home</button>
                        </li>
                        <li class="nav-item " role="presentation">
                            <button class="nav-link text-dark" id="players-tab" data-toggle="tab" data-target="#players"
                                type="button" role="tab" aria-controls="players" aria-selected="false">players</button>
                        </li>

                        <li class="nav-item " role="presentation">
                            <button class="nav-link text-dark" id="announce-tab" data-toggle="tab" data-target="#announce"
                                type="button" role="tab" aria-controls="announce"
                                aria-selected="false">announce</button>
                        </li>

                    </ul>
                </div>
                <div class="col-md-3 text-md-right">
                    <div class="actionBtn">
                        <?php if(isset($_GET['num-gen'])): ?>
                            <?php
                                $num_gen = $_GET['num-gen'];
                                // $url = str_replace("'",""," $num_gen");
                                $url = Crypt::decrypt($num_gen);
                                // dd($url);
                            ?>

                            <a href ="<?php echo e(route($url)); ?>" class="btn btn-success">Boards</a>
                        <?php else: ?>
                            <a href ="<?php echo e(route('admin.board_list')); ?>" class="btn btn-success">Boards</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                    <form action="" method="POST">
                        <div class="row mb-4">

                        </div>
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <?php
                                    $currentDate = carbon\Carbon::now();
                                    $dateFormat = $currentDate->format('Y-m-d H:i:00');

                                ?>
                                
                                <?php if($dateFormat >= $board_game_date->generate_number): ?>
                                    <div class="numberGenrator">
                                        <!--<button type="button" id="countSpin" class="btn btn-warning"> Spiner-->
                                        <!--    <span><?php echo e($data->spiner_count); ?></span>-->
                                        <!--</button>-->

                                        <button type="button" id="spinNumberCount" disabled class="btn btn-warning"> Spiner Numbers
                                            <span><?php echo e($data->spin_numbers); ?></span>
                                        </button>

                                        <button type="button" id="spiner" class="btn btn-warning q1">
                                            Spin
                                            
                                        </button>

                                        <button type="button" class="btn btn-warning q1 d-none"
                                            onclick="generateRandomNumbers('firstXnumber', 'firstYnumber')">1st Qtr</button>
                                        <button type="button" class="btn btn-warning q2 d-none"
                                            onclick="generateRandomNumbers('secondXnumber', 'secondYnumber')">2nd
                                            Qtr</button>
                                        <button type="button" class="btn btn-warning q3 d-none"
                                            onclick="generateRandomNumbers('thirdXnumber', 'thirdYnumber')">3rd Qtr</button>
                                        <button type="button" class="btn btn-warning q4 d-none"
                                            onclick="generateRandomNumbers('fourthXnumber', 'fourthYnumber')">4th
                                            Qtr</button>
                                        <button type="button" class="btn btn-danger clearBtn">Clear</button>

                                        <button type="button" class="btn btn-danger SpinsNumber">Number Spins</button>

                                    </div>
                                <?php endif; ?>



                                <div class="board_dates_details">
                                    <p>Select Square Deadline :
                                        <?php echo e(date('j-F-Y', strtotime($board_game_date->square_deadline))); ?></p>
                                    <p>Game Date : <?php echo e(date('j-F-Y', strtotime($board_game_date->game_date))); ?> </p>
                                    <p>Generate Number Date :
                                        <?php echo e(date('j-F-Y', strtotime($board_game_date->generate_number))); ?> </p>
                                    <p>Payment Deadline: <?php echo e(date('j-F-Y', strtotime($board_game_date->payment_deadline))); ?>

                                    </p>
                                </div>

                                <p class="text-end"><strong>Total number of squars (100) <br> && total numbers of buy
                                        (<?php echo e($squareBuyCountTotal); ?>)</strong></p>

                            </div>
                            <div class="col-md-12">


                                <div class="table-responsive">

                                    <table class="gamingBox spinTable" id="normalGamingTable">
                                        <h3 class="text-center"><?php echo e($board_game_date->team_name_x); ?></h3>
                                        <h3 class="yyy_text"><?php echo e($board_game_date->team_name_y); ?></h3>
                                        <thead>

                                        </thead>
                                        <?php
                                            $q1x = json_decode($data->q1x);
                                            $q2x = json_decode($data->q2x);
                                            $q3x = json_decode($data->q3x);
                                            $q4x = json_decode($data->q4x);

                                            $q1y = json_decode($data->q1y);
                                            $q2y = json_decode($data->q2y);
                                            $q3y = json_decode($data->q3y);
                                            $q4y = json_decode($data->q4y);
                                        ?>
                                        <tbody>

                                            
                                            <tr>
                                                <td class="lightYellow" colspan="4">1st</td>
                                                <?php if(isset($q1x)): ?>
                                                    <?php $__currentLoopData = $q1x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="lightYellow firstXnumber clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="lightYellow firstXnumber clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>



                                            </tr>

                                            <tr>
                                                <td class="lightYellow" rowspan="3">1st</td>
                                                <td class="orangeColor" colspan="3">2nd</td>
                                                <?php if(isset($q2x)): ?>
                                                    <?php $__currentLoopData = $q2x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="orangeColor secondXnumber clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="orangeColor secondXnumber clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>

                                            </tr>
                                            <tr>
                                                <td rowspan="2" class="orangeColor">2nd</td>
                                                <td colspan="2" class="lightBlue">3rd</td>
                                                <?php if(isset($q3x)): ?>
                                                    <?php $__currentLoopData = $q3x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="lightBlue thirdXnumber clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="lightBlue thirdXnumber clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>
                                            </tr>

                                            <tr>
                                                <td class="lightBlue">3rd</td>
                                                <td class="blueColor">4th</td>

                                                <?php if(isset($q4x)): ?>
                                                    <?php $__currentLoopData = $q4x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="blueColor fourthXnumber clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="blueColor fourthXnumber clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>
                                            </tr>

                                            <tr>
                                                <?php if(isset($q1y[0])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[0])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[0])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[0])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q3y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear">0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[1])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[1])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[1])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[1])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[2])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[2])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[2])): ?>
                                                    <td class="lightBlue thirdYnumber new clear"><span>
                                                            <?php echo e($q3y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[2])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[3])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[3])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[3])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[3])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear">0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[4])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[4])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[4])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[4])): ?>
                                                    <td class="blueColor fourthYnumber new clear"><span>
                                                            <?php echo e($q4y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[5])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[5])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[5])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[5])): ?>
                                                    <td class="blueColor fourthYnumber new clear"><span>
                                                            <?php echo e($q4y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[6])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[6])): ?>
                                                    <td class="orangeColor secondYnumber new clear"><span>
                                                            <?php echo e($q2y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[6])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[6])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y="" data-q2-y=""
                                                        data-q3-y="" data-q4-y="" data-q2-x="" data-q3-x=""
                                                        data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[7])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[7])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[7])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear">0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[7])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[8])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[8])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[8])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[8])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[9])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[9])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[9])): ?>
                                                    <td class="lightBlue thirdYnumber new clear"><span>
                                                            <?php echo e($q3y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[9])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <table class="<?php echo e($data->spiner_count == 4 ? 'gamingBox' : ''); ?>  finalTableResult" id="finalTableResultData">
                                        
                                        
                                        <thead>

                                        </thead>
                                        <?php
                                            $q1x = json_decode($data->q1x);
                                            $q2x = json_decode($data->q2x);
                                            $q3x = json_decode($data->q3x);
                                            $q4x = json_decode($data->q4x);

                                            $q1y = json_decode($data->q1y);
                                            $q2y = json_decode($data->q2y);
                                            $q3y = json_decode($data->q3y);
                                            $q4y = json_decode($data->q4y);
                                        ?>
                                        <tbody id="finalTableResultDataBody">

                                            
                                            <tr>
                                                <td class="lightYellow" colspan="4">1st</td>
                                                <?php if(isset($q1x)): ?>
                                                    <?php $__currentLoopData = $q1x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="lightYellow firstXnumber_finalTableResult clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="lightYellow firstXnumber_finalTableResult clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>



                                            </tr>

                                            <tr>
                                                <td class="lightYellow" rowspan="3">1st</td>
                                                <td class="orangeColor" colspan="3">2nd</td>
                                                <?php if(isset($q2x)): ?>
                                                    <?php $__currentLoopData = $q2x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="orangeColor secondXnumber_finalTableResult clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="orangeColor secondXnumber_finalTableResult clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>

                                            </tr>
                                            <tr>
                                                <td rowspan="2" class="orangeColor">2nd</td>
                                                <td colspan="2" class="lightBlue">3rd</td>
                                                <?php if(isset($q3x)): ?>
                                                    <?php $__currentLoopData = $q3x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="lightBlue thirdXnumber_finalTableResult clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="lightBlue thirdXnumber_finalTableResult clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>
                                            </tr>

                                            <tr>
                                                <td class="lightBlue">3rd</td>
                                                <td class="blueColor">4th</td>

                                                <?php if(isset($q4x)): ?>
                                                    <?php $__currentLoopData = $q4x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td class="blueColor fourthXnumber_finalTableResult clear">
                                                            <span><?php echo e($item); ?></span>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php for($i = 0; $i < 10; $i++): ?>
                                                        <td class="blueColor fourthXnumber_finalTableResult clear">0</td>
                                                    <?php endfor; ?>
                                                <?php endif; ?>
                                            </tr>

                                            <tr>
                                                <?php if(isset($q1y[0])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[0])): ?>
                                                    <td class="orangeColor  secondYnumber new clear">
                                                        <span><?php echo e($q2y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[0])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[0])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q3y[0]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear">0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[1])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[1])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[1])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[1])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[1]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[2])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[2])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[2])): ?>
                                                    <td class="lightBlue thirdYnumber new clear"><span>
                                                            <?php echo e($q3y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[2])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[2]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[3])): ?>
                                                    <td class="lightYellow firstYnumber new clear">
                                                        <span><?php echo e($q1y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[3])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[3])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear">0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[3])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[3]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear">0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[4])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[4])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[4])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[4])): ?>
                                                    <td class="blueColor fourthYnumber new clear"><span>
                                                            <?php echo e($q4y[4]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[5])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[5])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[5])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[5])): ?>
                                                    <td class="blueColor fourthYnumber new clear"><span>
                                                            <?php echo e($q4y[5]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[6])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[6])): ?>
                                                    <td class="orangeColor secondYnumber new clear"><span>
                                                            <?php echo e($q2y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[6])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[6])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[6]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[7])): ?>
                                                    <td class="lightYellow firstYnumber new clear"><span>
                                                            <?php echo e($q1y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[7])): ?>
                                                    <td class="orangeColor secondYnumber new clear">
                                                        <span><?php echo e($q2y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[7])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear">0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[7])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[7]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[8])): ?>
                                                    <td class="lightYellow  firstYnumber new clear"><span>
                                                            <?php echo e($q1y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow  firstYnumber clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[8])): ?>
                                                    <td class="orangeColor secondYnumber new  clear">
                                                        <span><?php echo e($q2y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber  clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[8])): ?>
                                                    <td class="lightBlue thirdYnumber new clear">
                                                        <span><?php echo e($q3y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[8])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[8]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber  clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                            <tr>

                                                <?php if(isset($q1y[9])): ?>
                                                    <td class="lightYellow firstYnumber new  clear">
                                                        <span><?php echo e($q1y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightYellow firstYnumber  clear"> 0 </td>
                                                <?php endif; ?>


                                                <?php if(isset($q2y[9])): ?>
                                                    <td class="orangeColor secondYnumber  new clear">
                                                        <span><?php echo e($q2y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="orangeColor secondYnumber  clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q3y[9])): ?>
                                                    <td class="lightBlue thirdYnumber new clear"><span>
                                                            <?php echo e($q3y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="lightBlue thirdYnumber clear"> 0</td>
                                                <?php endif; ?>


                                                <?php if(isset($q4y[9])): ?>
                                                    <td class="blueColor fourthYnumber new clear">
                                                        <span><?php echo e($q4y[9]); ?></span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class="blueColor fourthYnumber clear"> 0</td>
                                                <?php endif; ?>

                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                                <td>
                                                    <label class="gameBox" data-q1-x="" data-q1-y=""
                                                        data-q2-y="" data-q3-y="" data-q4-y="" data-q2-x=""
                                                        data-q3-x="" data-q4-x="">
                                                        <input type="checkbox" value="" class="checkboxSquare">
                                                        <div class="checkMark"></div>
                                                    </label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                    </form>

                </div>
                <div class="tab-pane fade" id="players" role="tabpanel" aria-labelledby="players-tab">



                    <div>
                        <p class="text-end mb-0 mt-4"> <strong> Total Paid Amount (<span id="totalAmountShow"></span>)
                                <br>
                                <span id="adminAmount"></span></strong></p>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Squares <?php echo e($price); ?></th>
                                <th scope="col">Team X</th>
                                <th scope="col">Team Y</th>
                                <th scope="col">Alias</th>
                                <th scope="col">Phone #</th>
                                <th scope="col">Email</th>
                                <th scope="col">Squares #</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Paid</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                                $count = 1;
                                $paidAmount = [];
                            ?>
                            <?php if(count($squareBuyCountUser) > 0): ?>
                                <?php $__currentLoopData = $squareBuyCountUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $Collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $Collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyTeamYArr => $teamYData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $teamYData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyTeamYName => $teamXArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $teamXArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyTeamXData => $teamXName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $teamXName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamXName => $dataUsers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $dataUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div>
                                                                    <tr>
                                                                        <th scope="row"><?php echo e($count++); ?></th>
                                                                        <td>
                                                                            <?php
                                                                                if (!empty($keyTeamXData)) {
                                                                                    if (in_array($user->id, json_decode($keyTeamXData))) {
                                                                                        echo $teamXName;
                                                                                    }
                                                                                }
                                                                            ?>
                                                                        </td>
                                                                        <td>
                                                                            <?php
                                                                                if (!empty($keyTeamYArr)) {
                                                                                    if (in_array($user->id, json_decode($keyTeamYArr))) {
                                                                                        echo $keyTeamYName;
                                                                                    }
                                                                                }
                                                                            ?>
                                                                        </td>
                                                                        <td><?php echo e($user->alias); ?></td>
                                                                        <td><?php echo e($user->number); ?></td>
                                                                        <td><?php echo e($user->email); ?></td>
                                                                        <td><?php echo e($keys); ?></td>
                                                                        <td><?php echo e($keys * $price); ?></td>
                                                                        <td>
                                                                            <?php if($key == 1): ?>
                                                                                <?php
                                                                                    $paidAmount[] = $keys * $price;
                                                                                ?>

                                                                                <strong><span
                                                                                        class="text-success">Paid</span></strong>
                                                                            <?php else: ?>
                                                                                <strong><span
                                                                                        class="text-danger">Unpaid</span></strong>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td>
                                                                            <button type="button"
                                                                                class="btn btn-danger"
                                                                                data-toggle="modal"
                                                                                data-target="#exampleModal<?php echo e($user->id); ?>">Delete</button>
                                                                        </td>
                                                                    </tr>
                                                                </div>

                                                                
                                                                <div class="modal fade"
                                                                    id="exampleModal<?php echo e($user->id); ?>"
                                                                    tabindex="-1" role="dialog"
                                                                    aria-labelledby="exampleModalLabel"
                                                                    aria-hidden="true">
                                                                    <div class="modal-dialog" role="document">
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <h5 class="modal-title"
                                                                                    id="exampleModalLabel">
                                                                                    Delete
                                                                                    User
                                                                                </h5>
                                                                                <button type="button" class="close"
                                                                                    data-dismiss="modal"
                                                                                    aria-label="Close">
                                                                                    <span
                                                                                        aria-hidden="true">&times;</span>
                                                                                </button>
                                                                            </div>
                                                                            <div class="modal-body text-center">
                                                                                Are you sure you want to delete this user?
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type="button"
                                                                                    class="btn btn-secondary"
                                                                                    data-dismiss="modal">Close</button>
                                                                                
                                                                                <a class="btn btn-danger"
                                                                                    href="<?php echo e(route('admin.game.board.destory', ['user_id' => $user->id, 'board_id' => $data->board_id, 'price' => $price])); ?>">Delete</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div>
                                    <tr>
                                        <th class="text-center" colspan="8">No recoards Available</th>
                                    </tr>
                                </div>
                            <?php endif; ?>

                        </tbody>
                    </table>

                </div>

                <?php

                    $totalAmount = 0; // Initialize a variable to store the total sum

                    foreach ($paidAmount as $a) {
                        // Convert $a to a numeric value in case it's not already
                        $a = floatval($a);

                        // Add the current value of $a to the totalAmount
                        $totalAmount += $a;
                    }

                ?>

                <input type="hidden" id="totalAmount" value="<?php echo e($totalAmount); ?>">

                <div class="tab-pane fade" id="announce" role="tabpanel" aria-labelledby="announce-tab">

                    <section class="our_winners_section">
                        <div class="container">
                            <?php

                                if (isset($winningUser->percentage)) {
                                    $percentage = json_decode($winningUser->percentage);
                                }

                                if (isset($winningUser->score)) {
                                    $score = json_decode($winningUser->score);
                                }

                                if (isset($winningUser->winning_number)) {
                                    $winningNumber = json_decode($winningUser->winning_number);
                                }

                                if (isset($winningUser->right_way)) {
                                    $rightWay = json_decode($winningUser->right_way);
                                }

                                if (isset($winningUser->right_way_name)) {
                                    $rightWayName = json_decode($winningUser->right_way_name);
                                }

                                if (isset($winningUser->right_way_price)) {
                                    $rightWayPrice = json_decode($winningUser->right_way_price);
                                }

                                if (isset($winningUser->plus2)) {
                                    $plus2 = json_decode($winningUser->plus2);
                                }

                                if (isset($winningUser->plus2_name)) {
                                    $plus2Name = json_decode($winningUser->plus2_name);
                                }

                                if (isset($winningUser->plus2_price)) {
                                    $plus2Price = json_decode($winningUser->plus2_price);
                                }

                                if (isset($winningUser->wrong_way)) {
                                    $wrongWay = json_decode($winningUser->wrong_way);
                                }

                                if (isset($winningUser->wrong_way_name)) {
                                    $wrongWayName = json_decode($winningUser->wrong_way_name);
                                }

                                if (isset($winningUser->wrong_way_price)) {
                                    $wrongWayPrice = json_decode($winningUser->wrong_way_price);
                                }

                                if (isset($winningUser->minus2)) {
                                    $minus2 = json_decode($winningUser->minus2);
                                }

                                if (isset($winningUser->minus2_name)) {
                                    $minus2Name = json_decode($winningUser->minus2_name);
                                }

                                if (isset($winningUser->minus2_price)) {
                                    $minus2Price = json_decode($winningUser->minus2_price);
                                }

                                $getPercentage = json_decode($getPercentage->percentage);

                            ?>

                            <div class="row pt-5">
                                <div class="col-md-5 d-none">
                                    <div class="perceantage_table">
                                        <table class="table ">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Qtr.</th>
                                                    <th scope="col">Right <br> Way</th>
                                                    <th scope="col">Wrong <br> Way</th>
                                                    <th scope="col">Plus <br> 2</th>
                                                    <th scope="col">Minus <br> 2</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        1st Qtr.
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[0])): ?> value="<?php echo e($percentage[0]); ?>" <?php elseif(isset($getPercentage[0])): ?> value="<?php echo e($getPercentage[0]); ?>" <?php else: ?>  value="9" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[1])): ?> value="<?php echo e($percentage[1]); ?>"  <?php elseif(isset($getPercentage[1])): ?> value="<?php echo e($getPercentage[1]); ?>"<?php else: ?>  value="6" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[2])): ?> value="<?php echo e($percentage[2]); ?>" <?php elseif(isset($getPercentage[2])): ?> value="<?php echo e($getPercentage[2]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[3])): ?> value="<?php echo e($percentage[3]); ?>" <?php elseif(isset($getPercentage[3])): ?> value="<?php echo e($getPercentage[3]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        2nd Qtr.
                                                    </td>

                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[4])): ?> value="<?php echo e($percentage[4]); ?>" <?php elseif(isset($getPercentage[4])): ?> value="<?php echo e($getPercentage[4]); ?>" <?php else: ?>  value="9" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>

                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[5])): ?> value="<?php echo e($percentage[5]); ?>" <?php elseif(isset($getPercentage[5])): ?> value="<?php echo e($getPercentage[5]); ?>" <?php else: ?>  value="6" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[6])): ?> value="<?php echo e($percentage[6]); ?>" <?php elseif(isset($getPercentage[6])): ?> value="<?php echo e($getPercentage[6]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[7])): ?> value="<?php echo e($percentage[7]); ?>" <?php elseif(isset($getPercentage[7])): ?> value="<?php echo e($getPercentage[7]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        3rd Qtr.
                                                    </td>

                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[8])): ?> value="<?php echo e($percentage[8]); ?>" <?php elseif(isset($getPercentage[8])): ?> value="<?php echo e($getPercentage[8]); ?>" <?php else: ?>  value="9" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[9])): ?> value="<?php echo e($percentage[9]); ?>" <?php elseif(isset($getPercentage[9])): ?> value="<?php echo e($getPercentage[9]); ?>" <?php else: ?>  value="6" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[10])): ?> value="<?php echo e($percentage[10]); ?>" <?php elseif(isset($getPercentage[10])): ?> value="<?php echo e($getPercentage[10]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[11])): ?> value="<?php echo e($percentage[11]); ?>" <?php elseif(isset($getPercentage[11])): ?> value="<?php echo e($getPercentage[11]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>

                                                </tr>
                                                <tr>
                                                    <td>
                                                        4th Qtr.
                                                    </td>

                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[12])): ?> value="<?php echo e($percentage[12]); ?>" <?php elseif(isset($getPercentage[12])): ?> value="<?php echo e($getPercentage[12]); ?>" <?php else: ?>  value="17" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[13])): ?> value="<?php echo e($percentage[13]); ?>" <?php elseif(isset($getPercentage[13])): ?> value="<?php echo e($getPercentage[13]); ?>" <?php else: ?>  value="12" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[14])): ?> value="<?php echo e($percentage[14]); ?>" <?php elseif(isset($getPercentage[14])): ?> value="<?php echo e($getPercentage[14]); ?>" <?php else: ?>  value="4" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="numericInput"
                                                            <?php if(isset($percentage[15])): ?> value="<?php echo e($percentage[15]); ?>" <?php elseif(isset($getPercentage[15])): ?> value="<?php echo e($getPercentage[15]); ?>" <?php else: ?>  value="4" <?php endif; ?>
                                                            min="1" max="99"><span>%</span>
                                                        <p class="text-danger errorMessage"></p>
                                                    </td>

                                                </tr>

                                            </tbody>
                                        </table>
                                        <p class="total_count_percent">100%</p>
                                    </div>

                                </div>

                                <div class="col-md-4">
                                    <div class="score_table">
                                        <table class="table ">
                                            <thead>
                                                <tr>
                                                    <th colspan="3">SCORES</th>
                                                </tr>
                                                <tr>
                                                    <th scope="col">Cow boys</th>
                                                    <th scope="col">Opp</th>
                                                    <th scope="col">
                                                        <?php if(isset($winningUser) && $winningUser->status == 1): ?>
                                                            <style>
                                                                .our_winners_section button:disabled {
                                                                    background-color: #19376b;
                                                                }

                                                                .our_winners_section button:disabled::after {
                                                                    content: "Disabled";
                                                                    margin-left: 5px;
                                                                    color: red;
                                                                    background-color: #c1c1c1;
                                                                    border-radius: 20px;
                                                                    padding: 1px;
                                                                    font-weight: bold;
                                                                    /* border: 2px solid #19376b; */
                                                                }
                                                            </style>
                                                        <?php endif; ?>
                                                        <button <?php if(isset($winningUser) && $winningUser->status == 1): ?> disabled <?php endif; ?>
                                                            id="clear_score_numbers">Clear
                                                            Score</button>
                                                    </th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <input type="number" class="score1 getScore" min="1"
                                                            <?php if(isset($score[0])): ?> value="<?php echo e($score[0]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td>
                                                        <input type="number" class="score2 getScore" min="1"
                                                            <?php if(isset($score[1])): ?> value="<?php echo e($score[1]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td class="quater_position">1st</td>

                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input type="number" class="score3 getScore" min="1"
                                                            <?php if(isset($score[2])): ?> value="<?php echo e($score[2]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td>
                                                        <input type="number" class="score4 getScore" min="1"
                                                            <?php if(isset($score[3])): ?> value="<?php echo e($score[3]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td class="quater_position">2nd</td>

                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input type="number" class="score5 getScore" min="1"
                                                            <?php if(isset($score[4])): ?> value="<?php echo e($score[4]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td>
                                                        <input type="number" class="score6 getScore" min="1"
                                                            <?php if(isset($score[5])): ?> value="<?php echo e($score[5]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td class="quater_position">3rd</td>

                                                </tr>
                                                <tr>
                                                    <td>
                                                        <input type="number" class="score7 getScore" min="1"
                                                            <?php if(isset($score[6])): ?> value="<?php echo e($score[6]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td>
                                                        <input type="number" class="score8 getScore" min="1"
                                                            <?php if(isset($score[7])): ?> value="<?php echo e($score[7]); ?>" <?php endif; ?>
                                                            max="2">
                                                    </td>
                                                    <td class="quater_position">4th</td>

                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="score_table winning_number">
                                        <table class="table ">
                                            <thead>
                                                <tr>
                                                    <th colspan="3">Winning Number</th>
                                                </tr>
                                                <tr>
                                                    <th scope="col">Cow boys</th>
                                                    <th scope="col">Opp</th>
                                                    <th scope="col">Qtr.</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td id="first" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[0])): ?>
                                                            <?php echo e($winningNumber[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td id="second" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[1])): ?>
                                                            <?php echo e($winningNumber[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="quater_position">1st</td>
                                                </tr>
                                                <tr>
                                                    <td id="third" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[2])): ?>
                                                            <?php echo e($winningNumber[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td id="fourth" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[3])): ?>
                                                            <?php echo e($winningNumber[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="quater_position">2nd</td>
                                                </tr>
                                                <tr>
                                                    <td id="fifth" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[4])): ?>
                                                            <?php echo e($winningNumber[4]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td id="sixth" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[5])): ?>
                                                            <?php echo e($winningNumber[5]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="quater_position">3rd</td>
                                                </tr>
                                                <tr>
                                                    <td id="seventh" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[6])): ?>
                                                            <?php echo e($winningNumber[6]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td id="eighth" class="filterWinningNumber">
                                                        <?php if(isset($winningNumber[7])): ?>
                                                            <?php echo e($winningNumber[7]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="quater_position">4th</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>

                            <div class="row py-5">

                                <div class="col-md-6">
                                    <div class="win_show_table">
                                        <table class="table table-bordered">
                                            <thead>

                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colspan="2" rowspan="2" class="lightBlueColor">
                                                        $<?php echo e($data->price); ?> <br>
                                                        Square</td>
                                                    <td colspan="2" class="ligthYellColor">Right way</td>
                                                    <td rowspan="2" class="ligthYellColor">Pay <br> Out</td>
                                                    <td rowspan="2" class="greenColor">Winner</td>
                                                </tr>
                                                <tr>

                                                    <td class="ligthYellColor">Cowboys</td>
                                                    <td class="ligthYellColor">Opp</td>

                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">1st. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWayFirst">
                                                        <?php if(isset($rightWay[0])): ?>
                                                            <?php echo e($rightWay[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWayFirst2">
                                                        <?php if(isset($rightWay[1])): ?>
                                                            <?php echo e($rightWay[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink rightWayWinnerAmount" id="rightWayFirstAmount">
                                                        <?php if(isset($rightWayPrice[0])): ?>
                                                            <?php echo e($rightWayPrice[0]); ?>

                                                        <?php endif; ?>
                                                    </td>

                                                    <td class="light_lightGreen gernal_qtr" id="1strightWayWinnerName">


                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?>
                                                            <?php if($userAliasArr['rightWayUser'][0] != 'null'): ?>
                                                                <?php echo e($userAliasArr['rightWayUser'][0]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                    </td>

                                                    <input type="hidden"
                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?> <?php if($userAliasArr['rightWayUser'][0] != 'null'): ?>
                                                        value="<?php echo e($userAliasArr['rightWayUser'][0]['id']); ?>"
                                                        <?php else: ?>
                                                        value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    class="rightWayWinnerId" id="1strightWayWinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">2nd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWaySecond">
                                                        <?php if(isset($rightWay[2])): ?>
                                                            <?php echo e($rightWay[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWaySecond2">
                                                        <?php if(isset($rightWay[3])): ?>
                                                            <?php echo e($rightWay[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink rightWayWinnerAmount"
                                                        id="rightWaySecondAmount">
                                                        <?php if(isset($rightWayPrice[1])): ?>
                                                            <?php echo e($rightWayPrice[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr rightWayWinnerName"
                                                        id="2ndrightWayWinnerName">


                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?>
                                                            <?php if($userAliasArr['rightWayUser'][1] != 'null'): ?>
                                                                <?php echo e($userAliasArr['rightWayUser'][1]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden"
                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?> <?php if($userAliasArr['rightWayUser'][1] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['rightWayUser'][1]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    class="rightWayWinnerId" id="2ndrightWayWinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">3rd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWayThird">
                                                        <?php if(isset($rightWay[4])): ?>
                                                            <?php echo e($rightWay[4]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWayThird2">
                                                        <?php if(isset($rightWay[5])): ?>
                                                            <?php echo e($rightWay[5]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink rightWayWinnerAmount" id="rightWayThirdAmount">
                                                        <?php if(isset($rightWayPrice[2])): ?>
                                                            <?php echo e($rightWayPrice[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr rightWayWinnerName"
                                                        id="3rdrightWayWinnerName">

                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?>
                                                            <?php if($userAliasArr['rightWayUser'][2] != 'null'): ?>
                                                                <?php echo e($userAliasArr['rightWayUser'][2]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden" class="rightWayWinnerId"
                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?> <?php if($userAliasArr['rightWayUser'][1] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['rightWayUser'][1]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="3rdrightWayWinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">4th. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWayFourth">
                                                        <?php if(isset($rightWay[6])): ?>
                                                            <?php echo e($rightWay[6]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr rightWayWinner"
                                                        id="rightWayFourth2">
                                                        <?php if(isset($rightWay[7])): ?>
                                                            <?php echo e($rightWay[7]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink rightWayWinnerAmount"
                                                        id="rightWayFourthAmount">
                                                        <?php if(isset($rightWayPrice[3])): ?>
                                                            <?php echo e($rightWayPrice[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr rightWayWinnerName"
                                                        id="4thrightWayWinnerName">

                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?>
                                                            <?php if($userAliasArr['rightWayUser'][3] != 'null'): ?>
                                                                <?php echo e($userAliasArr['rightWayUser'][3]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden" class="rightWayWinnerId"
                                                        <?php if(isset($userAliasArr['rightWayUser'])): ?> <?php if($userAliasArr['rightWayUser'][2] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['rightWayUser'][2]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="4thrightWayWinnerId">
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="win_show_table">
                                        <table class="table table-bordered">
                                            <thead>

                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colspan="2" rowspan="2" class="lightBlueColor">
                                                        $<?php echo e($data->price); ?> <br>
                                                        Square</td>
                                                    <td colspan="2" class="ligthYellColor">Plus 2</td>
                                                    <td rowspan="2" class="ligthYellColor">Pay <br> Out</td>
                                                    <td rowspan="2" class="greenColor">Winner</td>
                                                </tr>
                                                <tr>

                                                    <td class="ligthYellColor">Cowboys</td>
                                                    <td class="ligthYellColor">Opp</td>

                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">1st. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWayFirstPlus">
                                                        <?php if(isset($plus2[0])): ?>
                                                            <?php echo e($plus2[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWayFirst2Plus">
                                                        <?php if(isset($plus2[1])): ?>
                                                            <?php echo e($plus2[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink plus2WinnerAmount"
                                                        id="rightWayFirstPlusAmount">
                                                        <?php if(isset($plus2Price[0])): ?>
                                                            <?php echo e($plus2Price[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr plus2WinnerName"
                                                        id="1stplus2WinnerName">
                                                        <?php if(isset($userAliasArr['plus2User'])): ?>
                                                            <?php if($userAliasArr['plus2User'][0] != 'null'): ?>
                                                                <?php echo e($userAliasArr['plus2User'][0]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden" class="plus2WinnerId"
                                                        <?php if(isset($userAliasArr['plus2User'])): ?> <?php if($userAliasArr['plus2User'][0] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['plus2User'][0]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="1stplus2WinnerId">
                                                </tr>

                                                <tr>
                                                    <td colspan="2" class="lightGreen">2nd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWaySecondPlus">
                                                        <?php if(isset($plus2[2])): ?>
                                                            <?php echo e($plus2[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWaySecond2Plus">
                                                        <?php if(isset($plus2[3])): ?>
                                                            <?php echo e($plus2[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink plus2WinnerAmount"
                                                        id="rightWaySecondPlusAmount">
                                                        <?php if(isset($plus2Price[1])): ?>
                                                            <?php echo e($plus2Price[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr plus2WinnerName"
                                                        id="2ndplus2WinnerName">

                                                        <?php if(isset($userAliasArr['plus2User'])): ?>
                                                            <?php if($userAliasArr['plus2User'][1] != 'null'): ?>
                                                                <?php echo e($userAliasArr['plus2User'][1]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden" class="plus2WinnerId"
                                                        <?php if(isset($userAliasArr['plus2User'])): ?> <?php if($userAliasArr['plus2User'][1] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['plus2User'][1]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="2ndplus2WinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">3rd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWayThirdPlus">
                                                        <?php if(isset($plus2[4])): ?>
                                                            <?php echo e($plus2[4]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWayThird2Plus">
                                                        <?php if(isset($plus2[5])): ?>
                                                            <?php echo e($plus2[5]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink plus2WinnerAmount"
                                                        id="rightWayThirdPlusAmount">
                                                        <?php if(isset($plus2Price[2])): ?>
                                                            <?php echo e($plus2Price[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr plus2WinnerName"
                                                        id="3rdplus2WinnerName">
                                                        <?php if(isset($userAliasArr['plus2User'])): ?>
                                                            <?php if($userAliasArr['plus2User'][2] != 'null'): ?>
                                                                <?php echo e($userAliasArr['plus2User'][2]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="plus2WinnerId"
                                                        <?php if(isset($userAliasArr['plus2User'])): ?> <?php if($userAliasArr['plus2User'][2] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['plus2User'][2]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="3rdplus2WinnerId">
                                                </tr>

                                                <tr>
                                                    <td colspan="2" class="lightGreen">4th. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWayFourthPlus">
                                                        <?php if(isset($plus2[6])): ?>
                                                            <?php echo e($plus2[6]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr plus2WayWinner"
                                                        id="rightWayFourth2Plus">
                                                        <?php if(isset($plus2[7])): ?>
                                                            <?php echo e($plus2[7]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink plus2WinnerAmount"
                                                        id="rightWayFourthPlusAmount">
                                                        <?php if(isset($plus2Price[3])): ?>
                                                            <?php echo e($plus2Price[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr plus2WinnerName"
                                                        id="4thplus2WinnerName">
                                                        <?php if(isset($userAliasArr['plus2User'])): ?>
                                                            <?php if($userAliasArr['plus2User'][3] != 'null'): ?>
                                                                <?php echo e($userAliasArr['plus2User'][3]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="plus2WinnerId"
                                                        <?php if(isset($userAliasArr['plus2User'])): ?> <?php if($userAliasArr['plus2User'][3] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['plus2User'][3]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="4thplus2WinnerId">
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="win_show_table">
                                        <table class="table table-bordered">
                                            <thead>

                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colspan="2" rowspan="2" class="lightBlueColor">
                                                        $<?php echo e($data->price); ?> <br>
                                                        Square</td>
                                                    <td colspan="2" class="ligthYellColor">Wrong way</td>
                                                    <td rowspan="2" class="ligthYellColor">Pay <br> Out</td>
                                                    <td rowspan="2" class="greenColor">Winner</td>
                                                </tr>
                                                <tr>

                                                    <td class="ligthYellColor">Cowboys</td>
                                                    <td class="ligthYellColor">Opp</td>

                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">1st. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWayFirst">
                                                        <?php if(isset($wrongWay[0])): ?>
                                                            <?php echo e($wrongWay[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWayFirst2">
                                                        <?php if(isset($wrongWay[1])): ?>
                                                            <?php echo e($wrongWay[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink wrongWayWinnerAmount" id="wrongWayFirstAmount">
                                                        <?php if(isset($wrongWayPrice[0])): ?>
                                                            <?php echo e($wrongWayPrice[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr wrongWayWinnerName"
                                                        id="1stwrongWayWinnerName">

                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?>
                                                            <?php if($userAliasArr['wrongWayUser'][0] != 'null'): ?>
                                                                <?php echo e($userAliasArr['wrongWayUser'][0]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden" class="wrongWayWinnerId"
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?> <?php if($userAliasArr['wrongWayUser'][0] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['wrongWayUser'][0]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="1stwrongWayWinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">2nd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWaySecond">
                                                        <?php if(isset($wrongWay[2])): ?>
                                                            <?php echo e($wrongWay[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWaySecond2">
                                                        <?php if(isset($wrongWay[3])): ?>
                                                            <?php echo e($wrongWay[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink wrongWayWinnerAmount"
                                                        id="wrongWaySecondAmount">
                                                        <?php if(isset($wrongWayPrice[1])): ?>
                                                            <?php echo e($wrongWayPrice[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr wrongWayWinnerName"
                                                        id="2ndwrongWayWinnerName">
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?>
                                                            <?php if($userAliasArr['wrongWayUser'][1] != 'null'): ?>
                                                                <?php echo e($userAliasArr['wrongWayUser'][1]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        

                                                    </td>
                                                    <input type="hidden" class="wrongWayWinnerId"
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?> <?php if($userAliasArr['wrongWayUser'][1] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['wrongWayUser'][1]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="2ndwrongWayWinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">3rd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWayThird">
                                                        <?php if(isset($wrongWay[4])): ?>
                                                            <?php echo e($wrongWay[4]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWayThird2">
                                                        <?php if(isset($wrongWay[5])): ?>
                                                            <?php echo e($wrongWay[5]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink wrongWayWinnerAmount" id="wrongWayThirdAmount">
                                                        <?php if(isset($wrongWayPrice[2])): ?>
                                                            <?php echo e($wrongWayPrice[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr wrongWayWinnerName"
                                                        id="3rdwrongWayWinnerName">
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?>
                                                            <?php if($userAliasArr['wrongWayUser'][2] != 'null'): ?>
                                                                <?php echo e($userAliasArr['wrongWayUser'][2]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="wrongWayWinnerId"
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?> <?php if($userAliasArr['wrongWayUser'][2] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['wrongWayUser'][2]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="3rdwrongWayWinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">4th. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWayFourth">
                                                        <?php if(isset($wrongWay[6])): ?>
                                                            <?php echo e($wrongWay[6]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr wrongWayWinner"
                                                        id="wrongWayFourth2">
                                                        <?php if(isset($wrongWay[7])): ?>
                                                            <?php echo e($wrongWay[7]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink wrongWayWinnerAmount"
                                                        id="wrongWayFourthAmount">
                                                        <?php if(isset($wrongWayPrice[3])): ?>
                                                            <?php echo e($wrongWayPrice[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr wrongWayWinnerName"
                                                        id="4thwrongWayWinnerName">
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?>
                                                            <?php if($userAliasArr['wrongWayUser'][3] != 'null'): ?>
                                                                <?php echo e($userAliasArr['wrongWayUser'][3]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="wrongWayWinnerId"
                                                        <?php if(isset($userAliasArr['wrongWayUser'])): ?> <?php if($userAliasArr['wrongWayUser'][3] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['wrongWayUser'][3]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="4thwrongWayWinnerId">
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="win_show_table">
                                        <table class="table table-bordered">
                                            <thead>

                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colspan="2" rowspan="2" class="lightBlueColor">
                                                        $<?php echo e($data->price); ?> <br>
                                                        Square</td>
                                                    <td colspan="2" class="ligthYellColor">Minus 2</td>
                                                    <td rowspan="2" class="ligthYellColor">Pay <br> Out</td>
                                                    <td rowspan="2" class="greenColor">Winner</td>
                                                </tr>
                                                <tr>

                                                    <td class="ligthYellColor">Cowboys</td>
                                                    <td class="ligthYellColor">Opp</td>

                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">1st. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWayFirstMinus">
                                                        <?php if(isset($minus2[0])): ?>
                                                            <?php echo e($minus2[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWayFirst2Minus">
                                                        <?php if(isset($minus2[1])): ?>
                                                            <?php echo e($minus2[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink minus2WinnerAmount"
                                                        id="rightWayFirstMinusAmount">
                                                        <?php if(isset($minus2Price[0])): ?>
                                                            <?php echo e($minus2Price[0]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr minus2WinnerName"
                                                        id="1stminus2WinnerName">
                                                        <?php if(isset($userAliasArr['minus2User'])): ?>
                                                            <?php if($userAliasArr['minus2User'][0] != 'null'): ?>
                                                                <?php echo e($userAliasArr['minus2User'][0]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="minus2WinnerId"
                                                        <?php if(isset($userAliasArr['minus2User'])): ?> <?php if($userAliasArr['minus2User'][0] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['minus2User'][0]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="1stminus2WinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">2nd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWaySecondMinus">
                                                        <?php if(isset($minus2[2])): ?>
                                                            <?php echo e($minus2[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWaySecond2Minus">
                                                        <?php if(isset($minus2[3])): ?>
                                                            <?php echo e($minus2[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink minus2WinnerAmount"
                                                        id="rightWaySecondMinusAmount">
                                                        <?php if(isset($minus2Price[1])): ?>
                                                            <?php echo e($minus2Price[1]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr minus2WinnerName"
                                                        id="2ndminus2WinnerName">
                                                        <?php if(isset($userAliasArr['minus2User'])): ?>
                                                            <?php if($userAliasArr['minus2User'][1] != 'null'): ?>
                                                                <?php echo e($userAliasArr['minus2User'][1]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="minus2WinnerId"
                                                        <?php if(isset($userAliasArr['minus2User'])): ?> <?php if($userAliasArr['minus2User'][1] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['minus2User'][1]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="2ndminus2WinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">3rd. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWayThirdMinus">
                                                        <?php if(isset($minus2[4])): ?>
                                                            <?php echo e($minus2[4]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWayThird2Minus">
                                                        <?php if(isset($minus2[5])): ?>
                                                            <?php echo e($minus2[5]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink minus2WinnerAmount"
                                                        id="rightWayThirdMinusAmount">
                                                        <?php if(isset($minus2Price[2])): ?>
                                                            <?php echo e($minus2Price[2]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr minus2WinnerName"
                                                        id="3rdminus2WinnerName">
                                                        <?php if(isset($userAliasArr['minus2User'])): ?>
                                                            <?php if($userAliasArr['minus2User'][2] != 'null'): ?>
                                                                <?php echo e($userAliasArr['minus2User'][2]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="minus2WinnerId"
                                                        <?php if(isset($userAliasArr['minus2User'])): ?> <?php if($userAliasArr['minus2User'][2] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['minus2User'][2]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="3rdminus2WinnerId">
                                                </tr>
                                                <tr>
                                                    <td colspan="2" class="lightGreen">4th. Qtr.</td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWayFourthMinus">
                                                        <?php if(isset($minus2[6])): ?>
                                                            <?php echo e($minus2[6]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="ligthYellColor gernal_qtr minus2WayWinner"
                                                        id="rightWayFourth2Minus">
                                                        <?php if(isset($minus2[7])): ?>
                                                            <?php echo e($minus2[7]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="lightPink minus2WinnerAmount"
                                                        id="rightWayFourthMinusAmount">
                                                        <?php if(isset($minus2Price[3])): ?>
                                                            <?php echo e($minus2Price[3]); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="light_lightGreen gernal_qtr minus2WinnerName"
                                                        id="4thminus2WinnerName">
                                                        <?php if(isset($userAliasArr['minus2User'])): ?>
                                                            <?php if($userAliasArr['minus2User'][3] != 'null'): ?>
                                                                <?php echo e($userAliasArr['minus2User'][3]['alias']); ?>

                                                            <?php else: ?>
                                                                null
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        
                                                    </td>
                                                    <input type="hidden" class="minus2WinnerId"
                                                        <?php if(isset($userAliasArr['minus2User'])): ?> <?php if($userAliasArr['minus2User'][3] != 'null'): ?>
                                                    value="<?php echo e($userAliasArr['minus2User'][3]['id']); ?>"
                                                    <?php else: ?>
                                                    value="" <?php endif; ?>
                                                        <?php endif; ?>
                                                    id="4thminus2WinnerId">
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>

                            <button type="button" <?php if(isset($winningUser) && $winningUser->status == 1): ?> disabled <?php endif; ?>
                                class="btn btn-primary" id="saveWinnerData">Announce
                                Winner</button>
                        </div>
                    </section>

                </div>
            </div>


        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        
        finalTableHtml = '';

        var specialCount = parseInt("<?php echo e($data->spiner_count); ?>");

        
        var spin_numbers = parseInt("<?php echo e($data->spin_numbers); ?>");



        $(document).ready(function() {


            $('.SpinsNumber').click(function(){


                function random_item(items)
                {
                    return items[Math.floor(Math.random()*items.length)];
                }

                var items = [1,2,3,4,5,6,7,8,9];
                // console.log(random_item(items));

                var url = "<?php echo e(route('admin.game.board.spinerUpdate')); ?>";

                    var randomNumber = random_item(items);
                    var data = {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'id': "<?php echo e($id); ?>",
                        'random_number' : randomNumber,
                        'type' : 'randomNumber',
                    };

                    let Res = AjaxRequest(url, data);

                    console.log(Res);
                    $('#spinNumberCount').text('Spiner Numbers ' + randomNumber);
                    $('#countSpin').text('Spiner 0');
                    spin_numbers = randomNumber;
                    specialCount = 0;
                    // $('#spiner').attr('disabled', false);

            });

            if (specialCount <= spin_numbers) {
                $('.finalTableResult').hide();
                $('#addButton').attr('disabled', true);

                $('.spinTable').show();
            } else {
                $('.spinTable').hide();

                $('.finalTableResult').show();
                $('#addButton').removeAttr('disabled', true);

                // $('.new span, .firstXnumber span, .secondXnumber span, .thirdXnumber span, .fourthXnumber span')
                //     .css('visibility', 'visible');

            }

            $('#spiner').click(function() {

                if (specialCount <= (spin_numbers - 1)) {
                    generateRandomNumbers('firstXnumber', 'firstYnumber')
                    generateRandomNumbers('secondXnumber', 'secondYnumber')
                    generateRandomNumbers('thirdXnumber', 'thirdYnumber')
                    generateRandomNumbers('fourthXnumber', 'fourthYnumber')

                    $('#countSpin span').text(specialCount++);

                    var url = "<?php echo e(route('admin.game.board.spinerUpdate')); ?>";

                    var data = {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'id': "<?php echo e($id); ?>",
                        'count': specialCount,
                    };

                    let Res = AjaxRequest(url, data);
                    console.log(Res);
                    if (Res.status == true) {
                        console.log(Res.data);
                        if (Res.data == spin_numbers) {

               
                            $('#countSpin span').text(Res.data);
                            
                            $('.spinTable').hide();

                            $('.finalTableResult').show();
                            $('.finalTableResult').addClass('gamingBox');

                            $('#addButton').removeAttr('disabled', true);


                            $('.spinTable').hide();

                            $('#finalTableResultDataBody').html(finalTableHtml);


                            jQuery('.finalTableResult .gameBox').each(function() {

                                // first y quard 
                                let verticalFirstCordinates = jQuery(this).parents('tr').find('.firstYnumber_finalTableResult').text();
                                jQuery(this).attr('data-q1-y', verticalFirstCordinates);

                                // second y quard 
                                let verticalSecondCordinates = jQuery(this).parents('tr').find('.secondYnumber_finalTableResult').text();
                                jQuery(this).attr('data-q2-y', verticalSecondCordinates);

                                // third y quard
                                let verticalThirdCordinates = jQuery(this).parents('tr').find('.thirdYnumber_finalTableResult').text();
                                jQuery(this).attr('data-q3-y', verticalThirdCordinates);

                                // fourth y quard
                                let verticalFourthCordinates = jQuery(this).parents('tr').find('.fourthYnumber_finalTableResult').text();
                                jQuery(this).attr('data-q4-y', verticalFourthCordinates);

                            });

                            $('.finalTableResult .firstYnumber  span').css('visibility','visible')
                            $('.finalTableResult .secondYnumber   span').css('visibility','visible')
                            $('.finalTableResult .thirdYnumber   span').css('visibility','visible')
                            $('.finalTableResult .fourthYnumber  span').css('visibility','visible')

                            $('.SpinsNumber').prop('disabled', true);
                            $('.clearBtn').prop('disabled', true);

                        }

                    }
                    return Res;

                } 
                // else {
                //     $('.spinTable').hide();

                //     $('.finalTableResult').show();
                // }




            });
            // new 


            var totalAmount = $('#totalAmount').val();
            $('#totalAmountShow').text(totalAmount);


            $('.numericInput').on('input', function() {
                const maxLength = 2;
                const $errorMessage = $(this).siblings('.errorMessage');

                if ($(this).val().length > maxLength) {
                    $(this).val($(this).val().slice(0, maxLength));
                    $errorMessage.text('Maximum length exceeded');
                } else {
                    $errorMessage.text('');
                }
            });


            jQuery('#clear_score_numbers').click(function() {
                jQuery('.score_table input[type=number]').each(function() {
                    jQuery(this).val('');

                    $('#first , #second , #third , #fourth , #fifth , #sixth , #seventh , #eighth')
                        .text('');
                });

                jQuery('.win_show_table tr').each(function() {
                    var $table = $(this).find('.gernal_qtr');
                    var $gernal_qtr_rows = $table.text('');
                });

            });

            // plus function 
            function plusVal(val) {
                var plusValue = parseInt(val) + 2;
                if (plusValue == 10) {
                    plusValue = 0;
                } else if (plusValue == 11) {
                    plusValue = 1;
                }
                return plusValue;
            }

            // minus function 
            function minusVal(val) {
                var minusValue = parseInt(val) - 2;

                if (Math.abs(minusValue) == 1) {
                    minusValue = 9;
                } else if (minusValue < 0) {
                    minusValue = 8;
                }

                if (minusValue > 9) {
                    minusValue = 0 - 1;
                }
                return minusValue;
            }

            // ajax function 
            function AjaxRequestFun(plusVal, plusVal2, minusVal, minusVal2, val1, val2, url) {
                var data = {
                    'board_id': "<?php echo e($data->board_id); ?>",
                    'price': "<?php echo e($data->price); ?>",
                    'part': "<?php echo e($data->part); ?>",
                    'firstValuePlus': plusVal,
                    'secondValuePlus': plusVal2,
                    'firstValueMinus': minusVal,
                    'secondValueMinus': minusVal2,
                    'first': val1,
                    'second': val2,
                    '_token': "<?php echo e(csrf_token()); ?>",
                }
                let Res = AjaxRequest(url, data);
                return Res;
            }


            // first start
            jQuery(".score1").change(function() {
                let val = jQuery(this).val();

                updateFirstWinningNumbers(val);
            });

            function updateFirstWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();

                jQuery('#first').text(lastCharacter);

                let firstValue = $('#first').text();

                var firstValuePlus = plusVal(firstValue);
                var firstValueMinus = minusVal(firstValue);

                let secondValue = $('#second').text();
                let secondValuePlus = plusVal(secondValue);
                var secondValueMinus = minusVal(secondValue);

                $('#rightWayFirst').text(lastCharacter);
                $('#rightWayFirst2').text();
                $('#rightWayFirstPlus').text(firstValuePlus);
                $('#rightWayFirst2Plus').text();
                $('#wrongWayFirst').text();
                $('#wrongWayFirst2').text(lastCharacter);
                $('#rightWayFirstMinus').text(firstValueMinus);
                $('#rightWayFirst2Minus').text();

                var url = "<?php echo e(route('admin.set_winner_first.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#1strightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#1strightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#1stplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#1stplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#1stwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#1stwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#1stminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#1stminus2WinnerId').val(firstRes.data.minus2.user.id);
            }
            // first end

            // second start
            jQuery(".score2").change(function() {
                let val = jQuery(this).val();

                updateSecondWinningNumbers(val);
            });

            function updateSecondWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#second').text(lastCharacter);


                let firstValue = $('#first').text();
                let firstValuePlus = plusVal(firstValue);

                let secondValue = $('#second').text();
                let secondValuePlus = plusVal(secondValue);

                var firstValueMinus = minusVal(firstValue);
                var secondValueMinus = minusVal(secondValue);


                $('#rightWayFirst').text(firstValue);
                $('#rightWayFirst2').text(secondValue);
                $('#rightWayFirstPlus').text(firstValuePlus);
                $('#rightWayFirst2Plus').text(secondValuePlus);
                $('#wrongWayFirst').text(secondValue);
                $('#wrongWayFirst2').text(firstValue);
                $('#rightWayFirstMinus').text(firstValueMinus);
                $('#rightWayFirst2Minus').text(secondValueMinus);

                var url = "<?php echo e(route('admin.set_winner_first.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#1strightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#1strightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#1stplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#1stplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#1stwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#1stwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#1stminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#1stminus2WinnerId').val(firstRes.data.minus2.user.id);

            }

            // second end

            // third start
            jQuery(".score3").change(function() {
                let val = jQuery(this).val();

                updateThirdWinningNumbers(val);
            });

            function updateThirdWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#third').text(lastCharacter);


                let firstValue = $('#third').text();

                var firstValuePlus = plusVal(firstValue);
                var firstValueMinus = minusVal(firstValue);

                let secondValue = $('#fourth').text();
                let secondValuePlus = plusVal(secondValue);
                var secondValueMinus = minusVal(secondValue);


                $('#rightWaySecond').text(lastCharacter);
                $('#rightWaySecond2').text();
                $('#rightWaySecondPlus').text(firstValuePlus);
                $('#rightWaySecond2Plus').text();
                $('#wrongWaySecond').text();
                $('#wrongWaySecond2').text(lastCharacter);
                $('#rightWaySecondMinus').text(firstValueMinus);
                $('#rightWaySecond2Minus').text();


                var url = "<?php echo e(route('admin.set_winner_second.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#2ndrightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#2ndrightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#2ndplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#2ndplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#2ndwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#2ndwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#2ndminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#2ndminus2WinnerId').val(firstRes.data.minus2.user.id);


            }
            // third end

            // fourth start
            jQuery(".score4").change(function() {
                let val = jQuery(this).val();

                updateFourthWinningNumbers(val);
            });

            function updateFourthWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#fourth').text(lastCharacter);


                let firstValue = $('#third').text();
                let firstValuePlus = plusVal(firstValue);

                let secondValue = $('#fourth').text();
                let secondValuePlus = plusVal(secondValue);

                var firstValueMinus = minusVal(firstValue);
                var secondValueMinus = minusVal(secondValue);


                $('#rightWaySecond').text(firstValue);
                $('#rightWaySecond2').text(secondValue);
                $('#rightWaySecondPlus').text(firstValuePlus);
                $('#rightWaySecond2Plus').text(secondValuePlus);
                $('#wrongWaySecond').text(secondValue);
                $('#wrongWaySecond2').text(firstValue);
                $('#rightWaySecondMinus').text(firstValueMinus);
                $('#rightWaySecond2Minus').text(secondValueMinus);

                var url = "<?php echo e(route('admin.set_winner_second.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#2ndrightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#2ndrightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#2ndplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#2ndplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#2ndwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#2ndwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#2ndminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#2ndminus2WinnerId').val(firstRes.data.minus2.user.id);


            }
            // fourth end

            // fifth start
            jQuery(".score5").change(function() {
                let val = jQuery(this).val();

                updateFifthWinningNumbers(val);
            });

            function updateFifthWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#fifth').text(lastCharacter);

                let firstValue = $('#fifth').text();
                let firstValuePlus = plusVal(firstValue);

                let secondValue = $('#sixth').text();
                let secondValuePlus = plusVal(secondValue);

                var firstValueMinus = minusVal(firstValue);
                var secondValueMinus = minusVal(secondValue);

                $('#rightWayThird').text(lastCharacter);
                $('#rightWayThird2').text();
                $('#rightWayThirdPlus').text(firstValuePlus);
                $('#rightWayThird2Plus').text();
                $('#wrongWayThird').text();
                $('#wrongWayThird2').text(lastCharacter);
                $('#rightWayThirdMinus').text(firstValueMinus);
                $('#rightWayThird2Minus').text();

                var url = "<?php echo e(route('admin.set_winner_third.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#3rdrightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#3rdrightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#3rdplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#3rdplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#3rdwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#3rdwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#3rdminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#3rdminus2WinnerId').val(firstRes.data.minus2.user.id);

            }
            // fifth end

            // sixth start
            jQuery(".score6").change(function() {
                let val = jQuery(this).val();

                updateSixthWinningNumbers(val);
            });

            function updateSixthWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#sixth').text(lastCharacter);


                let firstValue = $('#fifth').text();
                let firstValuePlus = plusVal(firstValue);

                let secondValue = $('#sixth').text();
                let secondValuePlus = plusVal(secondValue);

                var firstValueMinus = minusVal(firstValue);
                var secondValueMinus = minusVal(secondValue);


                $('#rightWayThird').text(firstValue);
                $('#rightWayThird2').text(secondValue);
                $('#rightWayThirdPlus').text(firstValuePlus);
                $('#rightWayThird2Plus').text(secondValuePlus);
                $('#wrongWayThird').text(secondValue);
                $('#wrongWayThird2').text(firstValue);
                $('#rightWayThirdMinus').text(firstValueMinus);
                $('#rightWayThird2Minus').text(secondValueMinus);

                var url = "<?php echo e(route('admin.set_winner_third.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#3rdrightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#3rdrightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#3rdplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#3rdplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#3rdwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#3rdwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#3rdminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#3rdminus2WinnerId').val(firstRes.data.minus2.user.id);

            }
            // sixth end

            // seventh start
            jQuery(".score7").change(function() {
                let val = jQuery(this).val();

                updateSeventhWinningNumbers(val);
            });

            function updateSeventhWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#seventh').text(lastCharacter);

                let firstValue = $('#seventh').text();
                let firstValuePlus = plusVal(firstValue);

                let secondValue = $('#eighth').text();
                let secondValuePlus = plusVal(secondValue);

                var firstValueMinus = minusVal(firstValue);
                var secondValueMinus = minusVal(secondValue);


                $('#rightWayFourth').text(lastCharacter);
                $('#rightWayFourth2').text();
                $('#rightWayFourthPlus').text(firstValuePlus);
                $('#rightWayFourth2Plus').text();
                $('#wrongWayFourth').text();
                $('#wrongWayFourth2').text(lastCharacter);
                $('#rightWayFourthMinus').text(firstValueMinus);
                $('#rightWayFourth2Minus').text();


                var url = "<?php echo e(route('admin.set_winner_fourth.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#4thrightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#4thrightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#4thplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#4thplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#4thwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#4thwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#4thminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#4thminus2WinnerId').val(firstRes.data.minus2.user.id);

            }
            // seventh end

            // eighth start
            jQuery(".score8").change(function() {
                let val = jQuery(this).val();

                updateEighthWinningNumbers(val);
            });

            function updateEighthWinningNumbers(val) {
                let num = val;
                let str = num.toString();
                let array = str.split('');
                let lastCharacter = array.pop();
                jQuery('#eighth').text(lastCharacter);

                let firstValue = $('#seventh').text();
                let firstValuePlus = plusVal(firstValue);

                let secondValue = $('#eighth').text();
                let secondValuePlus = plusVal(secondValue);

                var firstValueMinus = minusVal(firstValue);
                var secondValueMinus = minusVal(secondValue);


                $('#rightWayFourth').text(firstValue);
                $('#rightWayFourth2').text(secondValue);
                $('#rightWayFourthPlus').text(firstValuePlus);
                $('#rightWayFourth2Plus').text(secondValuePlus);
                $('#wrongWayFourth').text(secondValue);
                $('#wrongWayFourth2').text(firstValue);
                $('#rightWayFourthMinus').text(firstValueMinus);
                $('#rightWayFourth2Minus').text(secondValueMinus);

                var url = "<?php echo e(route('admin.set_winner_fourth.show')); ?>";

                let firstRes = AjaxRequestFun(firstValuePlus, secondValuePlus, firstValueMinus, secondValueMinus,
                    firstValue, secondValue, url);

                $('#4thrightWayWinnerName').text(firstRes.data.rightWay.user.alias);
                $('#4thrightWayWinnerId').val(firstRes.data.rightWay.user.id);

                $('#4thplus2WinnerName').text(firstRes.data.plus2.user.alias);
                $('#4thplus2WinnerId').val(firstRes.data.plus2.user.id);

                $('#4thwrongWayWinnerName').text(firstRes.data.wrongWay.user.alias);
                $('#4thwrongWayWinnerId').val(firstRes.data.wrongWay.user.id);

                $('#4thminus2WinnerName').text(firstRes.data.minus2.user.alias);
                $('#4thminus2WinnerId').val(firstRes.data.minus2.user.id);

            }
            // eighth end

            var price = "<?php echo e($data->price); ?>";
            var totalAmount = price * 100;
            var adminPercentage = (20 / 100) * totalAmount;
            var minusAdminPercentage = totalAmount - adminPercentage;

            $('#adminAmount').text('Admin Amount (' + adminPercentage + ')');

            var nullArr = [];
            var nullArrPercentage = [];
            $('.perceantage_table input[type=number]').each(function() {
                $(this).prop('readonly', true);
                let val = parseInt($(this).val());

                let percentage = (val / 100) * minusAdminPercentage;

                percentage = Math.floor(percentage)

                var arrPercentage = nullArrPercentage.push(percentage);

                let arr = nullArr.push(val);
            });

            showAmount(nullArrPercentage);


            $('.numericInput').change(function() {

                var nullArr = [];
                var nullArrPercentage = [];
                $('.perceantage_table input[type=number]').each(function() {

                    let val = parseInt($(this).val());

                    let percentage = (val / 100) * minusAdminPercentage;

                    percentage = Math.floor(percentage)

                    var arrPercentage = nullArrPercentage.push(percentage);

                    let arr = nullArr.push(val);
                });

                showAmount(nullArrPercentage);

                var sum = 0;

                $.each(nullArr, function(index, value) {
                    sum += value;
                });

                $('.total_count_percent').text(sum + "%");
            });


            function showAmount(nullArrPercentage) {
                $('#rightWayFirstAmount').text("$" + nullArrPercentage[0]);
                $('#rightWayFirstPlusAmount').text("$" + nullArrPercentage[1]);
                $('#wrongWayFirstAmount').text("$" + nullArrPercentage[2]);
                $('#rightWayFirstMinusAmount').text("$" + nullArrPercentage[3]);

                $('#rightWaySecondAmount').text("$" + nullArrPercentage[4]);
                $('#rightWaySecondPlusAmount').text("$" + nullArrPercentage[5]);
                $('#wrongWaySecondAmount').text("$" + nullArrPercentage[6]);
                $('#rightWaySecondMinusAmount').text("$" + nullArrPercentage[7]);

                $('#rightWayThirdAmount').text("$" + nullArrPercentage[8]);
                $('#rightWayThirdPlusAmount').text("$" + nullArrPercentage[9]);
                $('#wrongWayThirdAmount').text("$" + nullArrPercentage[10]);
                $('#rightWayThirdMinusAmount').text("$" + nullArrPercentage[11]);

                $('#rightWayFourthAmount').text("$" + nullArrPercentage[12]);
                $('#rightWayFourthPlusAmount').text("$" + nullArrPercentage[13]);
                $('#wrongWayFourthAmount').text("$" + nullArrPercentage[14]);
                $('#rightWayFourthMinusAmount').text("$" + nullArrPercentage[15]);
            }

            showAmount();

        });

        // winner users announce
        $(document).ready(function() {

            $('#saveWinnerData').click(function() {
                var validation = $('.getScore').val();

                if (validation == '') {
                    alert('please fill score field');
                } else {
                    const numericInput = [];
                    $('.numericInput').each(function() {
                        numericInput.push($(this).val());
                    });

                    const getScore = [];
                    $('.getScore').each(function() {
                        getScore.push($(this).val());
                    });

                    const filterWinningNumber = [];
                    $('.filterWinningNumber').each(function() {
                        filterWinningNumber.push($(this).text());
                    });

                    const rightWayWinner = [];
                    $('.rightWayWinner').each(function() {
                        rightWayWinner.push($(this).text());
                    });

                    const rightWayWinnerId = [];
                    $('.rightWayWinnerId').each(function() {
                        rightWayWinnerId.push($(this).val());
                    });

                    const rightWayWinnerAmount = [];
                    $('.rightWayWinnerAmount').each(function() {
                        rightWayWinnerAmount.push($(this).text());
                    });

                    const wrongWayWinner = [];
                    $('.wrongWayWinner').each(function() {
                        wrongWayWinner.push($(this).text());
                    });

                    const wrongWayWinnerId = [];
                    $('.wrongWayWinnerId').each(function() {
                        wrongWayWinnerId.push($(this).val());
                    });

                    const wrongWayWinnerAmount = [];
                    $('.wrongWayWinnerAmount').each(function() {
                        wrongWayWinnerAmount.push($(this).text());
                    });

                    const minus2WayWinner = [];
                    $('.minus2WayWinner').each(function() {
                        minus2WayWinner.push($(this).text());
                    });

                    const minus2WinnerId = [];
                    $('.minus2WinnerId').each(function() {
                        minus2WinnerId.push($(this).val());
                    });

                    const minus2WinnerAmount = [];
                    $('.minus2WinnerAmount').each(function() {
                        minus2WinnerAmount.push($(this).text());
                    });


                    const plus2WayWinner = [];
                    $('.plus2WayWinner').each(function() {
                        plus2WayWinner.push($(this).text());
                    });

                    const plus2WinnerId = [];
                    $('.plus2WinnerId').each(function() {
                        plus2WinnerId.push($(this).val());
                    });

                    const plus2WinnerAmount = [];
                    $('.plus2WinnerAmount').each(function() {
                        plus2WinnerAmount.push($(this).text());
                    });


                    var url = "<?php echo e(route('admin.winner_announce.show')); ?>";
                    var data = {
                        'board_id': "<?php echo e($data->board_id); ?>",
                        'price': "<?php echo e($data->price); ?>",
                        'part': "<?php echo e($data->part); ?>",
                        'percentage': numericInput,
                        'getScore': getScore,
                        'filterWinningNumber': filterWinningNumber,
                        'rightWayWinner': rightWayWinner,
                        'rightWayWinnerId': rightWayWinnerId,
                        'rightWayWinnerAmount': rightWayWinnerAmount,
                        'wrongWayWinner': wrongWayWinner,
                        'wrongWayWinnerId': wrongWayWinnerId,
                        'wrongWayWinnerAmount': wrongWayWinnerAmount,
                        'minus2WayWinner': minus2WayWinner,
                        'minus2WinnerId': minus2WinnerId,
                        'minus2WinnerAmount': minus2WinnerAmount,
                        'plus2WayWinner': plus2WayWinner,
                        'plus2WinnerId': plus2WinnerId,
                        'plus2WinnerAmount': plus2WinnerAmount,
                        '_token': "<?php echo e(csrf_token()); ?>",
                    };


                    let resWinnerAnnounce = AjaxRequest(url, data);
                    if (resWinnerAnnounce.status == true) {
                        alert(resWinnerAnnounce.message);
                    }
                }

            });
        });
    </script>

    <script>
        $(document).ready(function() {

            $('#addButton').click(function() {

                // var price = $('#price').val();
                var price = "<?php echo e($data->price); ?>";

                var data1x = $(".firstXnumber").text().split("");
                <?php if(isset($q1y)): ?>
                    var data1y = $(".firstYnumber.new").text().split("");
                <?php else: ?>
                    var data1y = $(".firstYnumber").text().split("");
                <?php endif; ?>

                var data2x = $(".secondXnumber").text().split("");
                <?php if(isset($q1y)): ?>
                    var data2y = $(".secondYnumber.new").text().split("");
                <?php else: ?>
                    var data2y = $(".secondYnumber").text().split("");
                <?php endif; ?>

                var data3x = $(".thirdXnumber").text().split("");
                <?php if(isset($q1y)): ?>
                    var data3y = $(".thirdYnumber.new").text().split("");
                <?php else: ?>
                    var data3y = $(".thirdYnumber").text().split("");
                <?php endif; ?>

                var data4x = $(".fourthXnumber").text().split("");
                <?php if(isset($q1y)): ?>
                    var data4y = $(".fourthYnumber.new").text().split("");
                <?php else: ?>
                    var data4y = $(".fourthYnumber").text().split("");
                <?php endif; ?>


                let data = {
                    'id': "<?php echo e($id); ?>",
                    'price': price,
                    'part': "<?php echo e($data->part); ?>",
                    'data1x': data1x,
                    'data1y': data1y,
                    'data2x': data2x,
                    'data2y': data2y,
                    'data3x': data3x,
                    'data3y': data3y,
                    'data4x': data4x,
                    'data4y': data4y,
                    '_token': '<?php echo e(csrf_token()); ?>',
                };

                let url = "<?php echo e(route('admin.game.board.add')); ?>";

                let response = AjaxRequest(url, data);

                if (response) {
                    alert(response.message);
                }

            });

            jQuery('.gameBox').each(function() {

                // first y quard 
                let verticalFirstCordinates = jQuery(this).parents('tr').find('.firstYnumber').text();
                jQuery(this).attr('data-q1-y', verticalFirstCordinates);

                // second y quard 
                let verticalSecondCordinates = jQuery(this).parents('tr').find('.secondYnumber').text();
                jQuery(this).attr('data-q2-y', verticalSecondCordinates);

                // third y quard
                let verticalThirdCordinates = jQuery(this).parents('tr').find('.thirdYnumber').text();
                jQuery(this).attr('data-q3-y', verticalThirdCordinates);

                // fourth y quard
                let verticalFourthCordinates = jQuery(this).parents('tr').find('.fourthYnumber').text();
                jQuery(this).attr('data-q4-y', verticalFourthCordinates);

            });

            jQuery('.gameBox .finalTableResult').each(function() {

                // first y quard 
                let verticalFirstCordinates = jQuery(this).parents('tr').find('.firstYnumber_finalTableResult').text();
                jQuery(this).attr('data-q1-y', verticalFirstCordinates);

                // second y quard 
                let verticalSecondCordinates = jQuery(this).parents('tr').find('.secondYnumber_finalTableResult').text();
                jQuery(this).attr('data-q2-y', verticalSecondCordinates);

                // third y quard
                let verticalThirdCordinates = jQuery(this).parents('tr').find('.thirdYnumber_finalTableResult').text();
                jQuery(this).attr('data-q3-y', verticalThirdCordinates);

                // fourth y quard
                let verticalFourthCordinates = jQuery(this).parents('tr').find('.fourthYnumber_finalTableResult').text();
                jQuery(this).attr('data-q4-y', verticalFourthCordinates);

            });

            $('tr').each(function(rowIndex) {

                var q1xData = <?php echo json_encode($q1x); ?>;
                var q2xData = <?php echo json_encode($q2x); ?>;
                var q3xData = <?php echo json_encode($q3x); ?>;
                var q4xData = <?php echo json_encode($q4x); ?>;

                $gameBoxes = $(this).find('.gameBox');

                $gameBoxes.each(function(index) {
                    var q1xValue = q1xData[index];
                    var q2xValue = q2xData[index];
                    var q3xValue = q3xData[index];
                    var q4xValue = q4xData[index];

                    $(this).attr({
                        "data-q1-x": q1xValue,
                        "data-q2-x": q2xValue,
                        "data-q3-x": q3xValue,
                        "data-q4-x": q4xValue,
                    });
                });
            });



            // get square data start
            let data = {
                'board_id': "<?php echo e($data->board_id); ?>",
                'price': "<?php echo e($data->price); ?>",
                'part': "<?php echo e($data->part); ?>",
                '_token': '<?php echo e(csrf_token()); ?>',
            };
            let url = "<?php echo e(route('admin.square_buy.show')); ?>";

            let res = AjaxRequest(url, data);

            if (res.status == true) {
                for (let i = 0; i < res.data.length; i++) {
                    $('tr').find('.gameBox').each(function() {
                        let box = $(this);
                        var checkMark = box.find('.checkMark');
                        var dataQ1X = $(this).data('q1-x');
                        var dataQ1Y = $(this).data('q1-y');
                        if (res.data[i].q1x == dataQ1X && res.data[i].q1y == dataQ1Y) {

                            box.addClass('alreadyBooked');
                            checkMark.removeClass('checkMark');
                            checkMark.addClass('checkMarkOwn');
                            checkMark.text(res.data[i].user.alias);
                        }
                    });
                }
            }
            finalTableHtml = $('#finalTableResultDataBody').html();

            if(specialCount !== (spin_numbers + 1)){
                $('#finalTableResultDataBody').html('')
            }


            if(( specialCount > 0 && spin_numbers > 0 ) && (specialCount >= spin_numbers) ){
                $('.SpinsNumber').prop('disabled', true);
                $('.clearBtn').prop('disabled', true);
            }
            // get square data end

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\office_work\square_junkie\resources\views/admin/game-board/index.blade.php ENDPATH**/ ?>