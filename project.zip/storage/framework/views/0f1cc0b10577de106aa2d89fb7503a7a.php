
<?php $__env->startSection('content'); ?>
    <?php

        if (isset($data->percentage)) {
            $percentage = json_decode($data->percentage);
        }

    ?>

    <div class="row pt-5">
        <div class="col-md-5">
            <div class="perceantage_table">
                <table class="table ">
                    <thead>
                        <tr>
                            <th scope="col">Qtr.</th>
                            <th scope="col">Right <br> Way</th>
                            <th scope="col">Wrong <br> Way</th>
                            <th scope="col">Plus <br> 2</th>
                            <th scope="col">Minus <br> 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                1st Qtr.
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[0])): ?> value="<?php echo e($percentage[0]); ?>" <?php else: ?>  value="9" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[1])): ?> value="<?php echo e($percentage[1]); ?>" <?php else: ?>  value="6" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[2])): ?> value="<?php echo e($percentage[2]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[3])): ?> value="<?php echo e($percentage[3]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                2nd Qtr.
                            </td>

                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[4])): ?> value="<?php echo e($percentage[4]); ?>" <?php else: ?>  value="9" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>

                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[5])): ?> value="<?php echo e($percentage[5]); ?>" <?php else: ?>  value="6" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[6])): ?> value="<?php echo e($percentage[6]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[7])): ?> value="<?php echo e($percentage[7]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                        </tr>

                        <tr>
                            <td>
                                3rd Qtr.
                            </td>

                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[8])): ?> value="<?php echo e($percentage[8]); ?>" <?php else: ?>  value="9" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[9])): ?> value="<?php echo e($percentage[9]); ?>" <?php else: ?>  value="6" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[10])): ?> value="<?php echo e($percentage[10]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[11])): ?> value="<?php echo e($percentage[11]); ?>" <?php else: ?>  value="3" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>

                        </tr>
                        <tr>
                            <td>
                                4th Qtr.
                            </td>

                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[12])): ?> value="<?php echo e($percentage[12]); ?>" <?php else: ?>  value="17" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[13])): ?> value="<?php echo e($percentage[13]); ?>" <?php else: ?>  value="12" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[14])): ?> value="<?php echo e($percentage[14]); ?>" <?php else: ?>  value="4" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>
                            <td>
                                <input type="number" class="numericInput"
                                    <?php if(isset($percentage[15])): ?> value="<?php echo e($percentage[15]); ?>" <?php else: ?>  value="4" <?php endif; ?>
                                    min="1" max="99"><span>%</span>
                                <p class="text-danger errorMessage"></p>
                            </td>

                        </tr>

                    </tbody>
                </table>
                <p class="total_count_percent">100%</p>
                <span id="above_percentage" class="text-danger"></span>
                <br>
                <button id="add_percentage_btn" class="btn btn-primary mb-3">Set Percentage</button>
                <br>
                <span id="success_msg" class="text-success font-weight-bolder"></span>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            var totalAmount = $('#totalAmount').val();
            $('#totalAmountShow').text(totalAmount);


            $('.numericInput').on('input', function() {
                const maxLength = 2;
                const $errorMessage = $(this).siblings('.errorMessage');

                if ($(this).val().length > maxLength) {
                    $(this).val($(this).val().slice(0, maxLength));
                    $errorMessage.text('Maximum length exceeded');
                } else {
                    $errorMessage.text('');
                }
            });

            $('.numericInput').change(function() {

                var nullArr = [];
                $('.perceantage_table input[type=number]').each(function() {

                    let val = parseInt($(this).val());

                    let arr = nullArr.push(val);
                });

                var sum = 0;

                $.each(nullArr, function(index, value) {
                    sum += value;
                });

                $('.total_count_percent').text(sum + "%");
                if (sum > 100) {
                    $('#above_percentage').text('Your Percentage is (100) Above');
                    $('#add_percentage_btn').prop('disabled', true);
                } else if (sum < 100) {
                    $('#above_percentage').text('Your Percentage is (100) below');
                    $('#add_percentage_btn').prop('disabled', true);
                } else {
                    $('#above_percentage').text('');
                    $('#add_percentage_btn').prop('disabled', false);
                }
            });



            $('#add_percentage_btn').on('click', function(e) {
                e.preventDefault();
                var nullArr = [];
                $('.perceantage_table input[type=number]').each(function() {

                    let val = parseInt($(this).val());

                    let percentage = (val / 100);

                    let arr = nullArr.push(val);
                });

                let url = "<?php echo e(route('admin.percentage.store')); ?>";
                let data = {
                    'values': nullArr,
                    '_token': "<?php echo e(csrf_token()); ?>",
                };
                let res = AjaxRequest(url, data);

                if (res.status == true) {
                    $('#success_msg').text(res.msg);
                    setTimeout(() => {
                        $('#success_msg').text('');
                    }, 3000);

                    for (let i = 0; i < res.data.length; i++) {
                        const element = res.data[i];

                        $('.perceantage_table input[type=number]').eq(i).val(element);
                    }
                }


            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/admin/percentage/percentage.blade.php ENDPATH**/ ?>