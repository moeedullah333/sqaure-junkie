<!DOCTYPE html>
<html lang="en">
<head>
    <title>Square Junkie</title>
    <meta charset="utf-8">
    <?php echo $__env->make('user.user-layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.user-layout.extrajs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="d-flex" id="wrapper">
    <?php echo $__env->make('user.user-layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.user-layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('user.user-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/cutommystgngs/public_html/square_junkie/resources/views/user/user-layout/main.blade.php ENDPATH**/ ?>